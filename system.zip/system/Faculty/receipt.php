<?php 
session_start();  
require_once '../db.php';    

// Check if the user is logged in 
if (!isset($_SESSION['user'])) {          
    // Redirect to login page if not logged in     
    header('Location: ../auth/login.php');          
    exit;  
}  

// Check if the receipt data exists in the session 
if (isset($_SESSION['receipt'])) {     
    $receipt = $_SESSION['receipt'];     
    $user_name = $receipt['user_name'];     
    $payment_amount = $receipt['payment_amount'];     
    $remaining_fine = $receipt['remaining_fine'];          
    
    // Optionally, you can clear the receipt session data after showing it     
    unset($_SESSION['receipt']); // Clears receipt session data after it's shown 
} else {     
    $_SESSION['message'] = "No payment data found.";     
    header('Location: payment_page.php'); // Redirect to the payment page if no receipt data is found     
    exit; 
} 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Receipt</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .receipt-container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 30px;
            width: 350px;
            text-align: center;
            animation: fadeIn 0.5s ease-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .receipt-container h2 {
            color: #333;
            margin-bottom: 20px;
            border-bottom: 2px solid #f0f0f0;
            padding-bottom: 10px;
        }
        .receipt-container p {
            margin: 15px 0;
            color: #666;
        }
        .receipt-container strong {
            color: #333;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #007bff;
            border: 1px solid #007bff;
            padding: 8px 15px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        .back-link:hover {
            background-color: #007bff;
            color: white;
            transform: translateY(-2px);
        }
        .payment-details {
            background-color: #f8f9fa;
            border-radius: 5px;
            padding: 15px;
            margin: 15px 0;
        }
    </style>
</head>
<body>
    <div class="receipt-container">
        <h2>Payment Receipt</h2>
        <div class="payment-details">
            <p><strong>User Name:</strong> <?php echo htmlspecialchars($user_name); ?></p>
            <p><strong>Payment Amount:</strong> <?php echo number_format($payment_amount, 2); ?> PHP</p>
            <p><strong>Remaining Fine:</strong> <?php echo number_format($remaining_fine, 2); ?> PHP</p>
        </div>
        <p><strong>Thank you for your payment!</strong></p>
        <a href="payment_page.php" class="back-link">Back to Payment Page</a>
    </div>
</body>
</html>