<?php
// calculate_fines.php

session_start();
require_once '../db.php';

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    header('Location: ../auth/login.php');
    exit;
}
// Calculate overdue books
// Calculate overdue books
$query = "
    SELECT borrow_records.id AS borrow_id, borrow_records.due_date, borrow_records.return_date, users.id AS user_id
    FROM borrow_records
    JOIN users ON borrow_records.user_id = users.id
    WHERE borrow_records.due_date < '" . date('Y-m-d') . "' AND borrow_records.return_date IS NULL
";


$stmt = $pdo->prepare($query);
$stmt->execute();
$overdue_books = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($overdue_books as $book) {
    // Calculate overdue time in minutes
    $overdue_time = (strtotime(date('Y-m-d')) - strtotime($book['due_date'])) / 60;
    
    // Calculate fine (assuming 5 pesos per minute)
    $fine_amount = $overdue_time * 5;

    // Insert the fine into the fines table
    $insert_query = "
        INSERT INTO fines (user_id, borrowing_id, fine_amount)
        VALUES (:user_id, :borrow_id, :fine_amount)
    ";

    $insert_stmt = $pdo->prepare($insert_query);
    $insert_stmt->execute([
        ':user_id' => $book['user_id'],
        ':borrow_id' => $book['borrow_id'],
        ':fine_amount' => $fine_amount,
    ]);
}

echo "Fines have been calculated and inserted.";
