<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            line-height: 1.6;
        }
        .payment-container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 30px;
            width: 350px;
        }
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
            border-bottom: 2px solid #f0f0f0;
            padding-bottom: 10px;
        }
        form div {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #666;
        }
        input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #0056b3;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: #007bff;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
        .error-message {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="payment-container">
        <?php 
        // Check if there is a session message (for example, user not found, error, etc.) 
        if (isset($_SESSION['message'])) {
            echo "<p class='error-message'>" . htmlspecialchars($_SESSION['message']) . "</p>";
            unset($_SESSION['message']); // Clear the session message after displaying it 
        } 
        ?>

        <h2>Payment Page</h2>

        <form action="pay_fine.php" method="POST">
            <div>
                <label for="membership_id">Membership ID:</label>
                <input type="text" id="membership_id" name="membership_id" required>
            </div>

            <div>
                <label for="payment_amount">Payment Amount (PHP):</label>
                <input type="number" id="payment_amount" name="payment_amount" min="0" step="0.01" required>
            </div>

            <div>
                <label for="fine_id">Fine ID:</label>
                <input type="text" id="fine_id" name="fine_id" required>
            </div>

            <button type="submit" name="pay_fine">Submit Payment</button>
        </form>

        <a href="faculty_dashboard.php" class="back-link">Back to Dashboard</a>
    </div>
</body>
</html>