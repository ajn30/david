<?php
session_start();
require_once '../db.php';

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    // Redirect to login page if not logged in
    header('Location: ../auth/login.php');
    exit;
}

// Handle fine payment
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['pay_fine'])) {
    $membership_id = htmlspecialchars($_POST['membership_id']);
    $payment_amount = $_POST['payment_amount'];

    // Ensure that the fine_id exists in POST data
    if (isset($_POST['fine_id'])) {
        $fine_id = $_POST['fine_id'];
    } else {
        // Handle the case where 'fine_id' is not set in the post data
        $_SESSION['message'] = "No fine ID found.";
        header('Location: payment_page.php'); // Redirect to payment page with error
        exit;
    }

    // Fetch the current fine of the user from the database
    $query = "SELECT id, name, fines FROM users WHERE membership_id = :membership_id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':membership_id', $membership_id, PDO::PARAM_STR);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $current_fine = $user['fines'];
        $new_fine = max(0, $current_fine - $payment_amount); // Ensure fines don't go negative

        // Update the fines in the users table
        $update_query = "UPDATE users SET fines = :new_fine WHERE id = :user_id";
        $update_stmt = $pdo->prepare($update_query);
        $update_stmt->bindParam(':new_fine', $new_fine, PDO::PARAM_INT);
        $update_stmt->bindParam(':user_id', $user['id'], PDO::PARAM_INT);
        $update_stmt->execute();

        // Record the payment in the payments table
        $payment_query = "INSERT INTO payments (user_id, amount) VALUES (:user_id, :amount)";
        $payment_stmt = $pdo->prepare($payment_query);
        $payment_stmt->bindParam(':user_id', $user['id'], PDO::PARAM_INT);
        $payment_stmt->bindParam(':amount', $payment_amount, PDO::PARAM_INT);
        $payment_stmt->execute();

        // Update the fines table to mark the fine as paid
        $fine_query = "
            UPDATE fines
            SET paid = 1, payment_date = NOW()
            WHERE id = :fine_id
        ";
        $fine_stmt = $pdo->prepare($fine_query);
        $fine_stmt->bindParam(':fine_id', $fine_id, PDO::PARAM_INT);
        $fine_stmt->execute();

        // Store receipt data in session
        $_SESSION['receipt'] = [
            'user_name' => $user['name'],
            'payment_amount' => $payment_amount,
            'remaining_fine' => $new_fine
        ];

        // Redirect to the receipt page
        header('Location: receipt.php');
        exit;
    } else {
        $_SESSION['message'] = "User not found.";
        header('Location: payment_page.php'); // Redirect if user is not found
        exit;
    }
}
?>