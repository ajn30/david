<?php
require_once('vendor/autoload.php');  // Load Composer's autoloader

use TCPDF;

session_start();

// Sample data (You should replace this with dynamic data, for example from session or database)
$user_name = 'John Doe';
$payment_amount = 500;
$remaining_fine = 100;

// Create new TCPDF object
$pdf = new TCPDF();

// Set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetTitle('Payment Receipt');

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('helvetica', '', 12);

// Title
$pdf->Cell(0, 10, 'Payment Receipt', 0, 1, 'C');
$pdf->Ln(10);

// Receipt details
$pdf->Cell(0, 10, 'User Name: ' . $user_name, 0, 1);
$pdf->Cell(0, 10, 'Payment Amount: ' . number_format($payment_amount, 2) . ' PHP', 0, 1);
$pdf->Cell(0, 10, 'Remaining Fine: ' . number_format($remaining_fine, 2) . ' PHP', 0, 1);
$pdf->Ln(10);
$pdf->Cell(0, 10, 'Thank you for your payment!', 0, 1, 'C');

// Output PDF to browser for printing
$pdf->Output('payment_receipt.pdf', 'I');  // 'I' displays the PDF in the browser, enabling printing
