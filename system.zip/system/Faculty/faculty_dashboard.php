<?php
session_start();
require_once '../db.php';

// Redirect to login if not logged in
if (!isset($_SESSION['user'])) {
    header('Location: ../auth/login.php');
    exit;
}

// Extract user name from the session
$userName = $_SESSION['user']['name'] ?? 'Faculty';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f9; margin: 0; padding: 20px; }
        .dashboard { max-width: 900px; margin: auto; padding: 20px; background: #fff; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); }
        button { padding: 10px 15px; background-color: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer; margin-right: 10px; }
        button:hover { background-color: #45a049; }
        .logout-btn { background-color: #f44336; }
        .logout-btn:hover { background-color: #e53935; }
        .pay-fine-btn { background-color: #007bff; }
        .pay-fine-btn:hover { background-color: #0056b3; }
    </style>
</head>
<body>
    <div class="dashboard">
        <h1>Welcome, <?php echo htmlspecialchars($userName); ?>!</h1>
        <p>You are logged in as Faculty.</p>

        <!-- Pay Fine Button -->
        <form action="payment_page.php" method="GET" style="display: inline;">
            <button type="submit" class="pay-fine-btn">Pay Fine</button>
        </form>

        <!-- Log Out Button -->
        <form action="../auth/logout.php" method="POST" style="display: inline;">
            <button type="submit" class="logout-btn">Log Out</button>
        </form>
    </div>
</body>
</html>
