<?php
session_start();
require_once '../db.php';  // Adjust path to db.php file

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    header('Location: ../auth/login.php');
    exit;
}

// Fetch user details
$user_id = $_SESSION['user']['id']; // Access user ID from session
$query = "SELECT email, password FROM users WHERE id = ?";
$stmt = $pdo->prepare($query);
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Initialize error array
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $old_password = $_POST['old_password'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validate old password
    if (!password_verify($old_password, $user['password'])) {
        $errors[] = "Old password is incorrect.";
    }

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    // Validate new password
    if ($password && $password !== $confirm_password) {
        $errors[] = "Passwords do not match.";
    }

    // If there are no errors, proceed with the update
    if (empty($errors)) {
        $hashed_password = $password ? password_hash($password, PASSWORD_DEFAULT) : null;

        // Build the update query
        $update_query = "UPDATE users SET email = ?";
        $params = [$email];
        $description = "Updated email to: $email";

        if ($hashed_password) {
            $update_query .= ", password = ?";
            $params[] = $hashed_password;
            $description .= " and updated password.";
        }

        $update_query .= " WHERE id = ?";
        $params[] = $user_id;

        $update_stmt = $pdo->prepare($update_query);

        if ($update_stmt->execute($params)) {
            // Log the action in activity_log
            $log_query = "INSERT INTO activity_log (UserID, ActionType, ResourceType, ResourceID, Description, IP_Address) 
                          VALUES (?, ?, ?, ?, ?, ?)";
            $log_stmt = $pdo->prepare($log_query);
            $ip_address = $_SERVER['REMOTE_ADDR'];
            $log_stmt->execute([ 
                $user_id,
                'Update Profile',
                'User',
                $user_id,
                $description,
                $ip_address
            ]);

            $_SESSION['success'] = "Profile updated successfully.";
            header('Location: staff_dashboard.php'); // Redirect to dashboard after success
            exit;
        } else {
            $errors[] = "Failed to update profile.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f6f9;
        }
        .container {
            margin-top: 50px;
        }
        .card-header {
            background-color: #007bff;
            color: white;
        }
        .card-body {
            background-color: #ffffff;
        }
        .table-hover tbody tr:hover {
            background-color: #f1f3f5;
        }
        .form-label {
            margin-top: 10px;
        }
        .form-control {
            margin-bottom: 15px;
        }
        .btn-secondary {
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card shadow-sm">
            <div class="card-header">
                <h2 class="mb-0">Edit Profile</h2>
            </div>
            <div class="card-body">
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if (isset($_SESSION['success'])): ?>
                    <p style="color:green;"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></p>
                <?php endif; ?>

                <form action="edit_profile.php" method="POST">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email:</label>
                        <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label for="old_password" class="form-label">Old Password:</label>
                        <input type="password" name="old_password" id="old_password" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">New Password :</label>
                        <input type="password" name="password" id="password" class="form-control">
                    </div>

                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Confirm Password:</label>
                        <input type="password" name="confirm_password" id="confirm_password" class="form-control">
                    </div>

                    <button type="submit" class="btn btn-primary">Update Profile</button>
                </form>
            </div>
            <div class="card-footer">
                <a href="staff_dashboard.php" class="btn btn-secondary">
                    <i class="bi bi-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
