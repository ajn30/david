<?php
// edit_user.php
require_once '../db.php';

if (isset($_GET['id'])) {
    // Get the user ID from the URL
    $user_id = $_GET['id'];

    // Fetch the user data from the database
    $query = "SELECT id, name, email, user_type FROM users WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->execute(['id' => $user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f6f9;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <?php if ($user): ?>
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h2 class="mb-0">Edit User</h2>
                </div>
                <div class="card-body">
                    <form action="update_user.php" method="POST">
                        <input type="hidden" name="id" value="<?php echo htmlspecialchars($user['id']); ?>">
                        
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control" id="name" name="name" 
                                   value="<?php echo htmlspecialchars($user['name']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" 
                                   value="<?php echo htmlspecialchars($user['email']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="user_type" class="form-label">Role</label>
                            <select class="form-select" id="user_type" name="user_type" required>
                                <option value="student" <?php if ($user['user_type'] == 'student') echo 'selected'; ?>>Student</option>
                                <option value="faculty" <?php if ($user['user_type'] == 'faculty') echo 'selected'; ?>>Faculty</option>
                                <option value="staff" <?php if ($user['user_type'] == 'staff') echo 'selected'; ?>>Staff</option>
                                <option value="admin" <?php if ($user['user_type'] == 'admin') echo 'selected'; ?>>Admin</option>
                            </select>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-save me-2"></i>Update User
                            </button>
                            <a href="view_users.php" class="btn btn-secondary">
                                <i class="bi bi-arrow-left me-2"></i>Back to User List
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        <?php else: ?>
            <div class="alert alert-danger">
                <i class="bi bi-exclamation-triangle me-2"></i>User not found.
            </div>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php 
} else {
    echo "<div class='container mt-5'>
            <div class='alert alert-warning'>
                <i class='bi bi-info-circle me-2'></i>No user ID provided.
            </div>
          </div>";
}
?>