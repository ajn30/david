<?php
// Connect to the database
$host = '127.0.0.1';
$username = 'root'; // your DB username
$password = ''; // your DB password
$dbname = 'efhan'; // your database name

$conn = new mysqli($host, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['AccessionNumber']) && isset($_POST['membership_id'])) {
        $accessionNumber = $_POST['AccessionNumber'];
        $membershipId = $_POST['membership_id'];

        if (empty($accessionNumber) || empty($membershipId)) {
            echo "Please provide both the Accession Number and Membership ID.";
        } else {
            // Check if the book exists and is available
            $sql = "SELECT * FROM libraryresources WHERE AccessionNumber = ? AND AvailabilityStatus = 'Available'";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $accessionNumber);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $resource = $result->fetch_assoc();
                $resourceId = $resource['ResourceID'];
                $title = $resource['Title'];
                $author = $resource['Author'];

                // Check if user exists
                $user_sql = "SELECT * FROM users WHERE membership_id = ?";
                $user_stmt = $conn->prepare($user_sql);
                $user_stmt->bind_param("s", $membershipId);
                $user_stmt->execute();
                $user_result = $user_stmt->get_result();

                if ($user_result->num_rows > 0) {
                    $user = $user_result->fetch_assoc();
                    $userId = $user['id'];

                    // Insert into borrowingtransactions
                    $borrowDate = date('Y-m-d');
                    $dueDate = date('Y-m-d', strtotime("+14 days"));

                    $transaction_sql = "INSERT INTO borrowingtransactions (UserID, ResourceID, BorrowDate, DueDate, Title, Author)
                                        VALUES (?, ?, ?, ?, ?, ?)";
                    $transaction_stmt = $conn->prepare($transaction_sql);
                    $transaction_stmt->bind_param("iissss", $userId, $resourceId, $borrowDate, $dueDate, $title, $author);

                    if ($transaction_stmt->execute()) {
                        $transactionId = $conn->insert_id;

                        // Insert into borrow_records
                        $borrow_records_sql = "INSERT INTO borrow_records (UserID, ResourceID, BorrowDate, return_date, Status, FineAmount, TransactionID, DueDate, Title, Author)
                                               VALUES (?, ?, ?, NULL, 'Borrowed', 0.00, ?, ?, ?, ?)";
                        $borrow_stmt = $conn->prepare($borrow_records_sql);
                        $borrow_stmt->bind_param("iisssss", $userId, $resourceId, $borrowDate, $transactionId, $dueDate, $title, $author);

                        if ($borrow_stmt->execute()) {
                            // Update libraryresources to 'Borrowed'
                            $update_sql = "UPDATE libraryresources SET AvailabilityStatus = 'Borrowed' WHERE ResourceID = ?";
                            $update_stmt = $conn->prepare($update_sql);
                            $update_stmt->bind_param("i", $resourceId);
                            $update_stmt->execute();

                            // Insert into activity log
                            $log_sql = "INSERT INTO activity_log (UserID, ActionType, ResourceType, ResourceID, Description, IP_Address) 
                                        VALUES (?, 'Borrow Book', 'Book', ?, ?, ?)";
                            $log_stmt = $conn->prepare($log_sql);
                            $ip_address = $_SERVER['REMOTE_ADDR'];
                            $description = "Borrowed book: $title by $author";

                            $log_stmt->bind_param("iiss", $userId, $resourceId, $description, $ip_address);
                            $log_stmt->execute();

                            echo "Book successfully borrowed. Due date: $dueDate";
                        } else {
                            echo "Error inserting into borrow_records: " . $conn->error;
                        }
                    } else {
                        echo "Error inserting into borrowingtransactions: " . $conn->error;
                    }
                } else {
                    echo "User not found with the given membership ID.";
                }
            } else {
                echo "Book is not available or invalid Accession Number.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrow Book</title>
</head>
<body>
    <h2>Borrow Book</h2>
    <form action="borrow_book.php" method="POST">
        <label for="AccessionNumber">Accession Number:</label><br>
        <input type="text" id="AccessionNumber" name="AccessionNumber" required><br><br>

        <label for="membership_id">Membership ID:</label><br>
        <input type="text" id="membership_id" name="membership_id" required><br><br>

        <input type="submit" value="Borrow Book">
    </form>
</body>
</html>

<?php
$conn->close();
?>
