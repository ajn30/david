<?php
// Connect to the database
$host = '127.0.0.1';
$username = 'root'; // your DB username
$password = ''; // your DB password
$dbname = 'efhan'; // your database name

$conn = new mysqli($host, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the TransactionID and MembershipID are set in the POST data
    if (isset($_POST['TransactionID']) && isset($_POST['membership_id'])) {
        $transactionId = $_POST['TransactionID'];
        $membershipId = $_POST['membership_id'];

        // Check if both TransactionID and membershipId are provided
        if (empty($transactionId) || empty($membershipId)) {
            echo "Please provide both the Transaction ID and Membership ID.";
        } else {
            // Use prepared statement to check if the transaction exists for the given membership ID
            $stmt = $conn->prepare("SELECT * FROM borrowingtransactions WHERE TransactionID = ? AND UserID IN (SELECT id FROM users WHERE membership_id = ?)");
            $stmt->bind_param("is", $transactionId, $membershipId);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                // Get ResourceID from the transaction
                $transaction = $result->fetch_assoc();
                $resourceId = $transaction['ResourceID'];

                // Begin a transaction to ensure all queries execute successfully
                $conn->begin_transaction();

                try {
                    // Step 1: Update the borrow_records table to mark the status as 'return'
                    $update_borrow_record_sql = "UPDATE borrow_records SET status = 'return' WHERE TransactionID = ?";
                    $stmt = $conn->prepare($update_borrow_record_sql);
                    $stmt->bind_param("i", $transactionId);
                    if (!$stmt->execute()) {
                        throw new Exception("Failed to update borrow_records table.");
                    }

                    // Step 2: Update the borrowingtransactions table to mark the book as returned
                    $update_transaction_sql = "UPDATE borrowingtransactions SET ReturnDate = NOW() WHERE TransactionID = ?";
                    $stmt = $conn->prepare($update_transaction_sql);
                    $stmt->bind_param("i", $transactionId);
                    if (!$stmt->execute()) {
                        throw new Exception("Failed to update borrowingtransactions table.");
                    }

                    // Step 3: Remove the returned resource from borrowingtransactions table
                    $delete_transaction_sql = "DELETE FROM borrowingtransactions WHERE TransactionID = ?";
                    $stmt = $conn->prepare($delete_transaction_sql);
                    $stmt->bind_param("i", $transactionId);
                    if (!$stmt->execute()) {
                        throw new Exception("Failed to remove resource from borrowingtransactions table.");
                    }

                    // Step 4: Update the resource availability status to 'Available'
                    $update_resource_sql = "UPDATE libraryresources SET AvailabilityStatus = 'Available' WHERE ResourceID = ?";
                    $stmt = $conn->prepare($update_resource_sql);
                    $stmt->bind_param("i", $resourceId);
                    if (!$stmt->execute()) {
                        throw new Exception("Failed to update resource availability status.");
                    }

                    // Commit the transaction
                    $conn->commit();
                    echo "Book successfully returned, borrow_records updated, and resource removed from borrowingtransactions.";
                } catch (Exception $e) {
                    // Rollback the transaction if any query fails
                    $conn->rollback();
                    echo "Error: " . $e->getMessage();
                }
            } else {
                echo "No such borrowing transaction found for the given Membership ID.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Return Book</title>
</head>
<body>
    <h2>Return Book</h2>
    <form action="return_book.php" method="POST">
        <label for="TransactionID">Transaction ID:</label><br>
        <input type="text" id="TransactionID" name="TransactionID" required><br><br>

        <label for="membership_id">Membership ID:</label><br>
        <input type="text" id="membership_id" name="membership_id" required><br><br>

        <input type="submit" value="Return Book">
    </form>
</body>
</html>

<?php
// Close the connection
$conn->close();
?>
