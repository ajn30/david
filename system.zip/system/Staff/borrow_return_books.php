<?php
// Include database connection
require_once '../db.php';

// Fetch the list of available books for borrowing (with AccessionNumber and other details)
try {
    $query = "SELECT ResourceID, Title, Author, AccessionNumber, AvailabilityStatus, Category, AcquisitionYear
              FROM libraryresources
              WHERE AvailabilityStatus = 'Available'"; // Only fetch available books
    $stmt = $pdo->query($query);
    $availableBooks = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error fetching books: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrow/Return Books</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        // Optional: Prevent default behavior to test if JavaScript is interfering
        document.addEventListener("DOMContentLoaded", function () {
            const returnBtn = document.querySelector('.return-btn');
            if (returnBtn) {
                returnBtn.addEventListener('click', function (e) {
                    // Log to the console to check if the link works
                    console.log("Return button clicked");
                });
            }
        });
    </script>
</head>
<body class="container py-4">

    <h1 class="mb-4">Borrow/Return Books</h1>

    <!-- Borrow Books Section -->
    <h2>Borrow a Book</h2>
    <p>Click the button below to borrow a book:</p>
    <a href="borrow_book.php" class="btn btn-primary">Borrow a Book</a>

    <hr>

    <!-- Return Books Section -->
    <h2>Return a Book</h2>
    <p>Click the button below to return a book:</p>
    <a href="return_book.php" class="btn btn-success return-btn">Return a Book</a> <!-- Ensure this links to 'return.php' -->

    <hr>

    <!-- Available Books Section -->
    <h2>Available Books</h2>
    <table class="table table-striped table-bordered mt-4">
        <thead>
            <tr>
                <th>Resource ID</th>
                <th>Title</th>
                <th>Author</th>
                <th>Accession Number</th>
                <th>Category</th>
                <th>Acquisition Year</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($availableBooks)): ?>
                <?php foreach ($availableBooks as $book): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($book['ResourceID']); ?></td>
                        <td><?php echo htmlspecialchars($book['Title']); ?></td>
                        <td><?php echo htmlspecialchars($book['Author']); ?></td>
                        <td><?php echo htmlspecialchars($book['AccessionNumber']); ?></td>
                        <td><?php echo htmlspecialchars($book['Category']); ?></td>
                        <td><?php echo htmlspecialchars($book['AcquisitionYear']); ?></td>
                        <td><?php echo htmlspecialchars($book['AvailabilityStatus']); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" class="text-center">No books available.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

</body>
</html>
