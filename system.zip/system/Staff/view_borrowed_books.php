<?php
session_start();
require_once '../db.php';

// Get all borrowed books along with the user name
$query = "SELECT borrow_records.id AS borrow_id, users.name AS user_name, users.membership_id, books.title, books.accession_number, borrow_records.borrow_date, borrow_records.due_date
          FROM borrow_records 
          JOIN books ON borrow_records.book_id = books.id 
          JOIN users ON borrow_records.user_id = users.id";
$stmt = $pdo->prepare($query);
$stmt->execute();
$borrowed_books = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrowed Books - Staff View</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        h1 {
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .back-button {
            width: 100%;
            padding: 10px;
            background-color: #f44336;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            margin-top: 20px;
        }

        .back-button:hover {
            background-color: #d32f2f;
        }

        .return-form {
            text-align: center;
            margin-top: 20px;
        }

        input[type="text"] {
            padding: 8px;
            margin-top: 10px;
            width: 200px;
        }
    </style>
</head>
<body>

    <h1>Borrowed Books - Staff View</h1>

    <?php if (isset($_SESSION['message'])): ?>
        <p style="color: green; text-align: center;"><?= $_SESSION['message']; ?></p>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <?php if (count($borrowed_books) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>User Name</th>
                    <th>Membership Number</th>
                    <th>Book Title</th>
                    <th>Borrowed Date</th>
                    <th>Due Date</th>
                    <th>Return Book</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($borrowed_books as $book): ?>
                    <tr>
                        <td><?= htmlspecialchars($book['user_name']); ?></td>
                        <td><?= htmlspecialchars($book['membership_id']); ?></td>
                        <td><?= htmlspecialchars($book['title']); ?></td>
                        <td><?= htmlspecialchars($book['borrow_date']); ?></td>
                        <td><?= htmlspecialchars($book['due_date']); ?></td>
                        <td>
                            <!-- Return Book Form -->
                            <form action="return.php" method="POST" class="return-form">
                                <input type="hidden" name="borrow_id" value="<?= $book['borrow_id']; ?>">
                                <label for="accession_number">Accession Number: </label>
                                <input type="text" id="accession_number" name="accession_number" required>
                                <button type="submit" name="return_book" class="back-button">Return Book</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No books have been borrowed yet.</p>
    <?php endif; ?>

    <!-- Back Button -->
    <form action="staff_dashboard.php" method="get">
        <button type="submit" class="back-button">Back to Dashboard</button>
    </form>

</body>
</html>
