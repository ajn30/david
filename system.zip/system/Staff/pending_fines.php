<?php
session_start();
require_once '../db.php';  // Ensure the path is correct for db.php

// Check if the user is logged in
if (!isset($_SESSION['user']) || !isset($_SESSION['user']['id'])) {
    // Redirect to login page if the session is not set
    header('Location: ../auth/login.php');
    exit;
}

$userId = $_SESSION['user']['id'];  // Get the logged-in user's ID

// Fetch pending fines based on overdue books
$stmt = $pdo->prepare("SELECT libraryresources.Title, borrow_records.due_date, 
                              DATEDIFF(CURDATE(), borrow_records.due_date) * 1 AS fine
                       FROM borrow_records
                       JOIN libraryresources ON borrow_records.ResourceID = libraryresources.ResourceID
                       WHERE borrow_records.UserID = ? 
                       AND borrow_records.return_date IS NULL 
                       AND DATEDIFF(CURDATE(), borrow_records.due_date) > 0");
$stmt->execute([$userId]);
$pendingFines = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate total pending fines
$totalFines = 0;
foreach ($pendingFines as $fine) {
    $totalFines += $fine['fine'];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pending Fines - Library</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqN5to8kSM+KnujsTM1Xf3kF5i6G7tu7zOe5w0F6Bz6uDkzZ6gK5I5u6g" crossorigin="anonymous">
    <style>
        .dashboard-header {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .dashboard-header h1 {
            font-size: 2rem;
            font-weight: 600;
        }
        .section-title {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 15px;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .profile-img {
            border-radius: 50%;
            max-width: 120px;
            margin-bottom: 10px;
        }
        .btn-custom {
            background-color: #007bff;
            color: white;
        }
        .btn-custom:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<!-- Dashboard Container -->
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar Section -->
        <div class="col-md-3 bg-light p-4 shadow-sm">
            <h2 class="text-center">Welcome, <?php echo htmlspecialchars($_SESSION['user']['name']); ?>!</h2>
            <div class="text-center mt-4">
                <img src="path_to_profile_image.jpg" class="profile-img" alt="Profile Image">
                <p><strong>Total Fines:</strong> PHP <?php echo number_format($totalFines, 2); ?></p>
                <a href="../auth/logout.php" class="btn btn-danger mb-3 w-100">Logout</a>
                <a href="edit_profile.php" class="btn btn-primary mb-3 w-100">Edit Profile</a>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="col-md-9 p-4">
            <div class="dashboard-header">
                <h1>Pending Fines</h1>
            </div>

            <div class="section-title">Your Pending Fines</div>
            <!-- Pending Fines Table -->
            <?php if ($pendingFines): ?>
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Book Title</th>
                            <th>Due Date</th>
                            <th>Fine (PHP)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pendingFines as $fine): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($fine['Title']); ?></td>
                                <td><?php echo date('F j, Y', strtotime($fine['due_date'])); ?></td>
                                <td><?php echo number_format($fine['fine'], 2); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="alert alert-info">
                    <strong>Total Pending Fines: </strong> PHP <?php echo number_format($totalFines, 2); ?>
                </div>
            <?php else: ?>
                <div class="alert alert-warning">
                    You have no pending fines.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pzjw8f+ua7Kw1TIq0dpU6RkFuYg9zjF6ptfJ3NO6E1JbLfHnX5Z+aZLR3IjyIh+m" crossorigin="anonymous"></script>

</body>
</html>
