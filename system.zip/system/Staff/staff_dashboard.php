<?php 
// Start the session
session_start(); 
require_once '../db.php';  

// Check if the user is logged in
if (!isset($_SESSION['user'])) {     
    // Redirect to login page if not logged in
    header('Location: ../auth/login.php');     
    exit; 
} 

// Fetch borrowing and returning data for the dashboard (example queries)
require_once '../db.php';
$borrowedBooks = $pdo->query("SELECT * FROM borrowingtransactions WHERE ReturnDate IS NULL")->fetchAll();
$returnedBooks = $pdo->query("SELECT * FROM borrowingtransactions WHERE ReturnDate IS NOT NULL")->fetchAll();

// Fetch recent activities with correct join
$recentActivities = $pdo->query(
    "SELECT bt.BorrowDate AS transaction_date, users.Name AS user_name, lr.Title AS book_title, lr.Author AS book_author
     FROM borrowingtransactions bt
     JOIN users ON bt.UserID = users.id
     JOIN libraryresources lr ON bt.ResourceID = lr.ResourceID
     ORDER BY bt.BorrowDate DESC LIMIT 5"
)->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard</title>
    <!-- Add your custom CSS here -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f6f9;
            padding-top: 50px;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 250px;
            background-color: #2c3e50;
            color: white;
            padding-top: 20px;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px;
            margin: 5px;
            border-radius: 4px;
        }
        .sidebar a:hover {
            background-color: #34495e;
        }
        .main-content {
            margin-left: 270px;
            padding: 20px;
        }
    </style>
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="sidebar">
        <h3 class="text-center">Staff Dashboard</h3>
        <a href="borrow_return_books.php">Borrow/Return Books</a>
        <a href="view_total_resources.php">View Resources</a>
        <a href="pending_fines.php">Pending Fines</a>
        <a href="../auth/logout.php">Logout</a>
    </div>

    <!-- Main Content Area -->
    <div class="main-content">
        <div class="container">
            <h2>Welcome, Staff Member</h2>
            <hr>

            <!-- Borrowing/Returning Overview -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">Borrowing Overview</div>
                        <div class="card-body">
                            <h5 class="card-title">Books Currently Borrowed: <?php echo count($borrowedBooks); ?></h5>
                            <p>Total number of books that are currently borrowed.</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">Returning Overview</div>
                        <div class="card-body">
                            <h5 class="card-title">Books Recently Returned: <?php echo count($returnedBooks); ?></h5>
                            <p>Recent returned books count and their status.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Activities -->
            <div class="card mb-4">
                <div class="card-header">Recent Borrowing and Returning Activities</div>
                <div class="card-body">
                    <ul class="list-group">
                        <?php foreach ($recentActivities as $activity): ?>
                            <li class="list-group-item">
                                <strong><?php echo htmlspecialchars($activity['user_name']); ?></strong> borrowed <em><?php echo htmlspecialchars($activity['book_title']); ?></em> on <?php echo $activity['transaction_date']; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>

           

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
