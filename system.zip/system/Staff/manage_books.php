<?php
session_start();
require_once '../db.php'; // Include the database connection file
require_once '../includes/helpers.php';

// Check if the user is an admin
if (!isset($_SESSION['user']) || $_SESSION['user']['user_type'] !== 'staff') {
    header('Location: ../auth/login.php');
    exit();
}

// Ensure $pdo (PDO instance) is used for database interactions
global $pdo;  // Use the PDO connection from db.php

// Fetch all books
$query = "SELECT * FROM books ORDER BY id DESC";
$books = $pdo->query($query);

// Add a new book
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_book'])) {
    $title = $_POST['title'];
    $author = $_POST['author'];
    $publisher = $_POST['publisher'];
    $genre = $_POST['genre'];
    $isbn = $_POST['isbn'];
    $accession_number = $_POST['accession_number'];

    // Insert the new book into the database
    $stmt = $pdo->prepare("INSERT INTO books (title, author, publisher, genre, isbn, accession_number) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$title, $author, $publisher, $genre, $isbn, $accession_number]);

    // Check if the book was added successfully
    if ($stmt) {
        $_SESSION['success'] = "Book added successfully!";
    } else {
        $_SESSION['error'] = "Failed to add book.";
    }
    header('Location: manage_books.php');
    exit();
}

// Delete a book
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];

    // Delete the book with the given ID
    $stmt = $pdo->prepare("DELETE FROM books WHERE id = ?");
    $stmt->execute([$delete_id]);

    if ($stmt) {
        $_SESSION['success'] = "Book deleted successfully!";
    } else {
        $_SESSION['error'] = "Failed to delete book.";
    }
    header('Location: manage_books.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Books</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f6f9;
            padding-top: 50px;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <h2 class="mb-4">Manage Books</h2>

        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-header">Add New Book</div>
                    <div class="card-body">
                        <form method="POST" action="manage_books.php">
                            <div class="mb-3">
                                <label for="title" class="form-label">Title:</label>
                                <input type="text" class="form-control" id="title" name="title" required>
                            </div>

                            <div class="mb-3">
                                <label for="author" class="form-label">Author:</label>
                                <input type="text" class="form-control" id="author" name="author" required>
                            </div>

                            <div class="mb-3">
                                <label for="publisher" class="form-label">Publisher:</label>
                                <input type="text" class="form-control" id="publisher" name="publisher" required>
                            </div>

                            <div class="mb-3">
                                <label for="genre" class="form-label">Genre:</label>
                                <input type="text" class="form-control" id="genre" name="genre" required>
                            </div>

                            <div class="mb-3">
                                <label for="isbn" class="form-label">ISBN:</label>
                                <input type="text" class="form-control" id="isbn" name="isbn" required>
                            </div>

                            <div class="mb-3">
                                <label for="accession_number" class="form-label">Accession Number:</label>
                                <input type="text" class="form-control" id="accession_number" name="accession_number" required>
                            </div>

                            <button type="submit" name="add_book" class="btn btn-primary">Add Book</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Book List</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Title</th>
                                        <th>Author</th>
                                        <th>Publisher</th>
                                        <th>Genre</th>
                                        <th>ISBN</th>
                                        <th>Accession Number</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($row = $books->fetch(PDO::FETCH_ASSOC)): ?>
                                        <tr>
                                            <td><?php echo $row['id']; ?></td>
                                            <td><?php echo htmlspecialchars($row['title']); ?></td>
                                            <td><?php echo htmlspecialchars($row['author']); ?></td>
                                            <td><?php echo htmlspecialchars($row['publisher']); ?></td>
                                            <td><?php echo htmlspecialchars($row['genre']); ?></td>
                                            <td><?php echo htmlspecialchars($row['isbn']); ?></td>
                                            <td><?php echo htmlspecialchars($row['accession_number']); ?></td>
                                            <td>
                                                <a href="edit_book.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-primary me-2">Edit</a>
                                                <a href="manage_books.php?delete_id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this book?');">Delete</a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-3">
            <form action="<?php echo $_SERVER['HTTP_REFERER']; ?>">
                <input type="submit" value="Back" class="btn btn-secondary">
            </form>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>