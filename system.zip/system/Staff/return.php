<?php
session_start();
require_once '../db.php';

// Handle the return of a book
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['return_book'])) {
    $borrow_id = htmlspecialchars($_POST['borrow_id']);
    $accession_number = htmlspecialchars($_POST['accession_number']); // Get the accession number

    try {
        // Start a database transaction
        $pdo->beginTransaction();

        // Check if the borrow record exists for the given accession number
        $query = "SELECT borrow_records.book_id, books.accession_number, books.available_quantity 
                  FROM borrow_records 
                  JOIN books ON borrow_records.book_id = books.id
                  WHERE borrow_records.id = :borrow_id AND books.accession_number = :accession_number";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':borrow_id', $borrow_id, PDO::PARAM_INT);
        $stmt->bindParam(':accession_number', $accession_number, PDO::PARAM_STR); // Match the accession number
        $stmt->execute();
        $borrow_record = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($borrow_record) {
            // Return the book: Delete the borrow record to mark it as returned
            $query = "DELETE FROM borrow_records WHERE id = :borrow_id";
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':borrow_id', $borrow_id, PDO::PARAM_INT);
            $stmt->execute();

            // Update the available quantity of the book
            $new_quantity = $borrow_record['available_quantity'] + 1;
            $query = "UPDATE books SET available_quantity = :available_quantity WHERE accession_number = :accession_number";
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':available_quantity', $new_quantity, PDO::PARAM_INT);
            $stmt->bindParam(':accession_number', $accession_number, PDO::PARAM_STR);
            $stmt->execute();

            // Commit the transaction
            $pdo->commit();

            // Log the return action in the activity log table
            $log_query = "INSERT INTO activity_log (UserID, ActionType, ResourceType, ResourceID, Description, IP_Address) 
                          VALUES (?, ?, ?, ?, ?, ?)";
            $log_stmt = $pdo->prepare($log_query);
            $user_id = $_SESSION['user']['id']; // Assuming user session contains user ID
            $ip_address = $_SERVER['REMOTE_ADDR'];
            $description = "User returned a book with Accession Number: " . $accession_number;
            $log_stmt->execute([
                $user_id,
                'Return Book',
                'Book',
                $borrow_record['book_id'],
                $description,
                $ip_address
            ]);

            $_SESSION['message'] = "Book successfully returned!";
        } else {
            $_SESSION['message'] = "Invalid Accession Number or Borrow Record not found.";
        }
    } catch (Exception $e) {
        // Roll back the transaction in case of error
        $pdo->rollBack();
        $_SESSION['message'] = "Error returning the book: " . $e->getMessage();
    }

    // Redirect to the borrowed books view page
    header('Location: view_borrowed_books.php');
    exit;
}
?>
