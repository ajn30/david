<?php
// view_user.php
session_start();
require_once '../db.php';

if (!isset($_SESSION['user'])) {
    header('Location: ../auth/login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f6f9;
        }
        .container {
            margin-top: 50px;
        }
        .table-hover tbody tr:hover {
            background-color: #f1f3f5;
        }
        .actions a {
            margin-right: 10px;
            text-decoration: none;
        }
        .actions a.edit {
            color: #007bff;
        }
        .actions a.delete {
            color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h2 class="mb-0">User Management</h2>
            </div>
            <div class="card-body">
                <?php
                // Fetch all users from the database
                $query = "SELECT id, name, email, user_type FROM users";
                $stmt = $pdo->prepare($query);
                $stmt->execute();

                if ($stmt->rowCount() > 0) {
                    echo '<div class="table-responsive">';
                    echo '<table class="table table-striped table-hover">';
                    echo '<thead class="table-light">';
                    echo '<tr>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Actions</th>
                          </tr>';
                    echo '</thead>';
                    echo '<tbody>';

                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        echo "<tr>
                                <td>" . htmlspecialchars($row['name']) . "</td>
                                <td>" . htmlspecialchars($row['email']) . "</td>
                                <td>" . htmlspecialchars(ucfirst($row['user_type'])) . "</td>
                                <td class='actions'>
                                    <a href='edit_user.php?id=" . htmlspecialchars($row['id']) . "' class='edit'>
                                        <i class='bi bi-pencil'></i> Edit
                                    </a>
                                    <a href='delete_user.php?id=" . htmlspecialchars($row['id']) . "' class='delete'>
                                        <i class='bi bi-trash'></i> Delete
                                    </a>
                                </td>
                              </tr>";
                    }

                    echo '</tbody>';
                    echo '</table>';
                    echo '</div>';
                } else {
                    echo "<div class='alert alert-info'>No users found.</div>";
                }
                ?>
            </div>
            <div class="card-footer">
                <a href="staff_dashboard.php" class="btn btn-secondary">
                    <i class="bi bi-arrow-left"></i> Back
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
