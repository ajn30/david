<?php
// update_user.php

require_once '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the updated user data from the form
    $user_id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $user_type = $_POST['user_type'];

    // Update the user information in the database
    $query = "UPDATE users SET name = :name, email = :email, user_type = :user_type WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        'name' => $name,
        'email' => $email,
        'user_type' => $user_type,
        'id' => $user_id
    ]);

    // Redirect back to the user list page after update
    header("Location: view_users.php");
    exit();
} else {
    echo "<p>Invalid request method.</p>";
}
