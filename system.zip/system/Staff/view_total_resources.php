<?php 
session_start();
require_once '../db.php';  // Ensure the path is correct for db.php

// Check if the user is logged in
if (!isset($_SESSION['user']) || !isset($_SESSION['user']['id'])) {
    // Redirect to login page if the session is not set
    header('Location: ../auth/login.php');
    exit;
}

$userId = $_SESSION['user']['id'];  // Get the logged-in user's ID

// Fetch the fines of the student based on overdue books
$stmt = $pdo->prepare("SELECT SUM(DATEDIFF(CURDATE(), borrow_records.due_date) * 1) AS total_fines 
                       FROM borrow_records 
                       WHERE borrow_records.UserID = ? 
                       AND borrow_records.return_date IS NULL 
                       AND DATEDIFF(CURDATE(), borrow_records.due_date) > 0");
$stmt->execute([$userId]);
$fines = $stmt->fetch(PDO::FETCH_ASSOC);
$totalFines = $fines['total_fines'] ? $fines['total_fines'] : 0;  // If no fines, set to 0

// Fetch borrow history of the student
$stmt = $pdo->prepare("SELECT borrow_records.RecordID, libraryresources.Title, borrow_records.BorrowDate, 
                              borrow_records.due_date, borrow_records.return_date 
                       FROM borrow_records 
                       JOIN libraryresources ON borrow_records.ResourceID = libraryresources.ResourceID 
                       WHERE borrow_records.UserID = ? 
                       ORDER BY borrow_records.BorrowDate DESC");
$stmt->execute([$userId]);
$borrowHistory = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle search functionality
$searchResults = [];
if (isset($_GET['search'])) {
    $searchQuery = '%' . $_GET['search'] . '%';
    $stmt = $pdo->prepare("SELECT ResourceID, Title, Author, Category, Available_quantity 
                           FROM libraryresources 
                           WHERE Title LIKE ? OR Author LIKE ? OR Category LIKE ?");
    $stmt->execute([$searchQuery, $searchQuery, $searchQuery]);
    $searchResults = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard - Total Resources</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqN5to8kSM+KnujsTM1Xf3kF5i6G7tu7zOe5w0F6Bz6uDkzZ6gK5I5u6g" crossorigin="anonymous">
    <style>
        .dashboard-header {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .dashboard-header h1 {
            font-size: 2rem;
            font-weight: 600;
        }
        .dashboard-card {
            border-radius: 8px;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
        }
        .card-body {
            padding: 20px;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .card-header {
            background-color: gray;
            color: white;
        }
        .btn-custom {
            background-color: #007bff;
            color: white;
        }
        .btn-custom:hover {
            background-color: #0056b3;
        }
        .profile-img {
            border-radius: 50%;
            max-width: 120px;
            margin-bottom: 10px;
        }
        .section-title {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 15px;
        }
        .search-bar {
            margin-bottom: 20px;
        }
        .sidebar-link {
            font-weight: bold;
        }
        .sidebar-link:hover {
            color: #007bff;
        }
        .profile-container {
            text-align: center;
        }
    </style>
</head>
<body>

<!-- Dashboard Container -->
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar Section -->
        <div class="col-md-3 bg-light p-4 shadow-sm">
            <h2 class="text-center">Welcome, <?php echo htmlspecialchars($_SESSION['user']['name']); ?>!</h2>
            <div class="profile-container mt-4">
                <img src="path_to_profile_image.jpg" class="profile-img" alt="Profile Image">
                <p><strong>Total Fines:</strong> PHP <?php echo number_format($totalFines, 2); ?></p>
                <a href="../auth/logout.php" class="btn btn-danger mb-3 w-100">Logout</a>
                <a href="edit_profile.php" class="btn btn-primary mb-3 w-100">Edit Profile</a>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="col-md-9 p-4">
            <div class="dashboard-header">
                <h1>View Total Resources</h1>
            </div>

            <!-- Search Resources Section -->
            <div class="section-title">Search Resources</div>
            <form method="GET" class="mb-4">
                <div class="input-group search-bar">
                    <input type="text" name="search" class="form-control" placeholder="Search by Title, Category, or Author" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                    <button type="submit" class="btn btn-outline-primary">Search</button>
                </div>
            </form>

            <!-- Search Results Table -->
            <?php if (!empty($searchResults)): ?>
                <h4>Search Results</h4>
                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Author</th>
                            <th>Category</th>
                            <th>Availability</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($searchResults as $resource): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($resource['Title']); ?></td>
                                <td><?php echo htmlspecialchars($resource['Author']); ?></td>
                                <td><?php echo htmlspecialchars($resource['Category']); ?></td>
                                <td><?php echo $resource['Available_quantity'] > 0 ? 'Available' : 'Not Available'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php elseif (isset($_GET['search'])): ?>
                <div class="alert alert-warning">No resources found matching your search.</div>
            <?php endif; ?>

            <!-- Borrow History Table -->
            <h3 class="mt-4">Borrow History</h3>
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Book Title</th>
                        <th>Borrow Date</th>
                        <th>Due Date</th>
                        <th>Return Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($borrowHistory): ?>
                        <?php foreach ($borrowHistory as $record): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($record['Title']); ?></td>
                                <td><?php echo date('F j, Y', strtotime($record['BorrowDate'])); ?></td>
                                <td><?php echo date('F j, Y', strtotime($record['due_date'])); ?></td>
                                <td>
                                    <?php 
                                    if ($record['return_date']) {
                                        echo date('F j, Y', strtotime($record['return_date']));
                                    } else {
                                        echo "Not Returned Yet";
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" class="text-center">No borrow history found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pzjw8f+ua7Kw1TIq0dpU6RkFuYg9zjF6ptfJ3NO6E1JbLfHnX5Z+aZLR3IjyIh+m" crossorigin="anonymous"></script>

</body>
</html>
