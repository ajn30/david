-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 02, 2024 at 08:54 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lms_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `ActivityLogID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `ActionType` varchar(50) NOT NULL,
  `ResourceType` varchar(50) NOT NULL,
  `ResourceID` varchar(50) NOT NULL,
  `Description` text DEFAULT NULL,
  `ActionDate` datetime DEFAULT current_timestamp(),
  `IP_Address` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`ActivityLogID`, `UserID`, `ActionType`, `ResourceType`, `ResourceID`, `Description`, `ActionDate`, `IP_Address`) VALUES
(1, 19, 'Update Profile', 'User', '19', 'Updated email to: danigie@gmail.com and updated password.', '2024-12-01 23:14:55', '::1'),
(2, 19, 'Update Profile', 'User', '19', 'Updated email to: danigie@gmail.com and updated password.', '2024-12-01 23:15:09', '::1'),
(3, 19, 'Update Profile', 'User', '19', 'Updated email to: danigie@gmail.com and updated password.', '2024-12-01 23:16:05', '::1'),
(4, 24, 'Update Profile', 'User', '24', 'Updated email to: suela@gmail.com and updated password.', '2024-12-01 23:46:48', '::1'),
(5, 4, 'Update Profile', 'User', '4', 'Updated email to: divinaefhan@gmail.com and updated password.', '2024-12-02 03:46:53', '::1'),
(6, 2, 'Borrow Book', 'Book', '26', 'User borrowed a book: Biag ni Lam-ang', '2024-12-02 22:57:50', '::1'),
(7, 3, 'Borrow Book', 'Book', '34', 'User borrowed a book: WALA NAKO SASABOT', '2024-12-02 22:58:11', '::1'),
(8, 2, 'Borrow Book', 'Book', '34', 'User borrowed a book: WALA NAKO SASABOT', '2024-12-02 23:06:36', '::1'),
(9, 2, 'Borrow Book', 'Book', '34', 'User borrowed a book: WALA NAKO SASABOT', '2024-12-02 23:15:29', '::1'),
(10, 2, 'Borrow Book', 'Book', '34', 'User borrowed a book: WALA NAKO SASABOT', '2024-12-02 23:16:24', '::1'),
(11, 2, 'Borrow Book', 'Book', '34', 'User borrowed a book: WALA NAKO SASABOT', '2024-12-02 23:18:22', '::1'),
(12, 2, 'Borrow Book', 'Book', '34', 'User borrowed a book: WALA NAKO SASABOT', '2024-12-02 23:20:36', '::1'),
(13, 2, 'Borrow Book', 'Book', '34', 'User borrowed a book: WALA NAKO SASABOT', '2024-12-02 23:24:54', '::1'),
(14, 2, 'Borrow Book', 'Book', '34', 'User borrowed a book: WALA NAKO SASABOT', '2024-12-02 23:25:26', '::1'),
(15, 2, 'Borrow Book', 'Book', '34', 'User borrowed a book: WALA NAKO SASABOT', '2024-12-02 23:31:12', '::1'),
(16, 2, 'Borrow Book', 'Book', '34', 'User borrowed a book: WALA NAKO SASABOT', '2024-12-02 23:34:10', '::1'),
(17, 2, 'Borrow Book', 'Book', '34', 'User borrowed a book: WALA NAKO SASABOT', '2024-12-02 23:37:08', '::1'),
(18, 2, 'Borrow Book', 'Book', '34', 'User borrowed a book: WALA NAKO SASABOT', '2024-12-02 23:37:35', '::1'),
(19, 2, 'Borrow Book', 'Book', '34', 'User borrowed a book: WALA NAKO SASABOT', '2024-12-02 23:39:35', '::1'),
(20, 2, 'Borrow Book', 'Book', '34', 'User borrowed a book: WALA NAKO SASABOT', '2024-12-02 23:40:06', '::1'),
(21, 2, 'Borrow Book', 'Book', '34', 'User borrowed a book: WALA NAKO SASABOT', '2024-12-02 23:44:20', '::1'),
(22, 2, 'Borrow Book', 'Book', '34', 'User borrowed a book: WALA NAKO SASABOT', '2024-12-02 23:44:46', '::1'),
(23, 1, 'Update Book', 'Book', '34', 'Book details updated: WALA NAKO SASABOT', '2024-12-02 23:52:04', '::1'),
(24, 1, 'Delete Book', 'Book', '3', 'Book deleted with ID: 3', '2024-12-03 00:18:20', '::1'),
(25, 1, 'Add Book', 'Book', '35', 'New book added: database', '2024-12-03 00:33:21', '::1'),
(26, 5, 'Add User', 'User', '5', 'User added: arnoldluengo', '2024-12-03 00:38:16', '::1'),
(27, 6, 'Add User', 'User', '6', 'User added: Rosa Rosalis', '2024-12-03 00:41:10', '::1'),
(28, 1, 'Delete Book', 'Book', '35', 'Book deleted with ID: 35', '2024-12-03 00:42:20', '::1'),
(29, 2, 'Borrow Book', 'Book', '26', 'User borrowed a book: Biag ni Lam-ang', '2024-12-03 01:03:48', '::1'),
(30, 2, 'Borrow Book', 'Book', '34', 'User borrowed a book: WALA NAKO SASABOT sa un nani', '2024-12-03 01:34:55', '::1'),
(31, 4, 'Return Book', 'Book', '26', 'User returned a book with Accession Number: ACC004', '2024-12-03 01:40:49', '::1'),
(32, 2, 'Borrow Book', 'Book', '26', 'User borrowed a book: Biag ni Lam-ang', '2024-12-03 01:41:16', '::1'),
(33, 7, 'Add User', 'User', '7', 'User added: Virgie Efhan', '2024-12-03 02:09:55', '::1');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(100) NOT NULL,
  `publisher` varchar(100) NOT NULL,
  `genre` varchar(50) NOT NULL,
  `isbn` varchar(20) NOT NULL,
  `accession_number` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `available_quantity` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `publisher`, `genre`, `isbn`, `accession_number`, `quantity`, `available_quantity`, `created_at`, `updated_at`) VALUES
(4, 'FOOL NOT TO YOUTH', 'MACK ARTHOUR', 'APOLO KINATO', 'HISTORY', '978-3-16-148410-0', 'BOOK02', 2, 0, '2024-11-30 18:29:09', '2024-12-01 19:42:39'),
(24, 'Noli Me Tangere', 'José Rizal', 'National Bookstore', 'Historical', '978-9876543211', 'ACC002', 2, 0, '2024-11-30 18:34:36', '2024-12-01 21:29:13'),
(25, 'El Filibusterismo', 'José Rizal', 'ABC Publishing', 'Historical', '978-1231231234', 'ACC003', 0, 0, '2024-11-30 18:34:36', '2024-11-30 18:34:36'),
(26, 'Biag ni Lam-ang', 'Anonymous', 'XYZ Books', 'Epic', '978-3216549870', 'ACC004', 2, 1, '2024-11-30 18:34:36', '2024-12-02 17:41:16'),
(27, 'Florante at Laura', 'Francisco Balagtas', 'XYZ Books', 'Poetry', '978-4561234567', 'ACC005', 0, 0, '2024-11-30 18:34:36', '2024-11-30 18:34:36'),
(28, 'Dekada 70', 'Lualhati Bautista', 'DEF Publishing', 'Fiction', '978-6543216548', 'ACC006', 0, 0, '2024-11-30 18:34:36', '2024-11-30 18:34:36'),
(29, 'The Lost Symbol', 'Dan Brown', 'ABC Publishing', 'Thriller', '978-3213213210', 'ACC007', 1, 0, '2024-11-30 18:34:36', '2024-12-01 21:39:54'),
(30, 'The Catcher in the Rye', 'J.D. Salinger', 'Penguin', 'Classic', '978-9876543212', 'ACC008', 0, 0, '2024-11-30 18:34:36', '2024-11-30 18:34:36'),
(34, 'WALA NAKO SASABOT sa un nani', 'AMBOT LANG', 'WALA KO KABALO', 'HISTORY', '978-3-16-148410-6', 'BOOK06', 5, 3, '2024-11-30 21:45:53', '2024-12-02 17:34:55');

-- --------------------------------------------------------

--
-- Table structure for table `book_categories`
--

CREATE TABLE `book_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `book_category_association`
--

CREATE TABLE `book_category_association` (
  `book_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `borrow_records`
--

CREATE TABLE `borrow_records` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `borrow_date` datetime DEFAULT current_timestamp(),
  `due_date` datetime DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `fine_amount` decimal(10,2) DEFAULT 0.00,
  `fine` decimal(10,2) DEFAULT 0.00,
  `fine_updated_at` timestamp NULL DEFAULT NULL,
  `deduction` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `borrow_records`
--

INSERT INTO `borrow_records` (`id`, `user_id`, `book_id`, `borrow_date`, `due_date`, `return_date`, `fine_amount`, `fine`, `fine_updated_at`, `deduction`) VALUES
(39, 2, 34, '2024-12-02 18:34:55', '2024-12-02 18:39:55', NULL, 0.00, 0.00, NULL, 0.00),
(40, 2, 26, '2024-12-02 18:41:16', '2024-12-02 18:46:16', NULL, 0.00, 0.00, NULL, 0.00);

--
-- Triggers `borrow_records`
--
DELIMITER $$
CREATE TRIGGER `update_fines` BEFORE UPDATE ON `borrow_records` FOR EACH ROW BEGIN
    IF NEW.due_date < CURDATE() AND NEW.return_date IS NULL THEN
        SET NEW.fine = DATEDIFF(CURDATE(), NEW.due_date) * 10; -- Palitan ang 10 ng iyong fine per day
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `fines`
--

CREATE TABLE `fines` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `borrowing_id` int(11) NOT NULL,
  `fine_amount` decimal(10,2) NOT NULL,
  `paid` tinyint(1) DEFAULT 0,
  `payment_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `user_id`, `amount`, `payment_date`) VALUES
(1, 2, 1.00, '2024-12-02 18:53:00'),
(2, 2, 1.00, '2024-12-02 19:30:25'),
(3, 2, 1.00, '2024-12-02 19:32:37'),
(4, 2, 1.00, '2024-12-02 19:33:25'),
(5, 2, 1.00, '2024-12-02 19:48:01');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `key` varchar(100) NOT NULL,
  `value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `key`, `value`) VALUES
(1, 'max_books_borrowed_by_student', '3'),
(2, 'max_books_borrowed_by_student', '3');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `user_type` enum('student','faculty','staff','admin') DEFAULT 'student',
  `password` varchar(255) NOT NULL,
  `membership_id` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fines` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `user_type`, `password`, `membership_id`, `created_at`, `updated_at`, `fines`) VALUES
(1, 'David Efhan', 'efhan@gmail.com', 'admin', '$2y$10$i4K5wKJOcEUhsXP9nxO32./dE/edQzH5PpeLbry/1XeZNlzq7zkTO', 'A2211600109', '2024-12-01 19:34:24', '2024-12-01 19:34:24', 0),
(2, 'Irish Efhan', 'irish@gmail.com', 'student', '$2y$10$zmPaLfdWidR1HJvAJVM2me2L28gs/vObcweXICjpYp1z5Q2SGK9JC', 'St2211600109', '2024-12-01 19:37:57', '2024-12-01 19:37:57', 0),
(3, 'Danigie Efhan', 'danigie@gmail.com', 'faculty', '$2y$10$iBTSFFaEIftLs.6Mc9XENegm0TwlQDEjhNrgwL37/yRx6YeAnrV0W', 'F2211600109', '2024-12-01 19:38:55', '2024-12-01 19:38:55', 0),
(4, 'Divina Efhan', 'divinaefhan@gmail.com', 'staff', '$2y$10$NydVOyZWokJ/VEKG3Cw/N.sVAqTxGC1OykF3vxdF.V0yR5m86zFGW', 'Stf2211600109', '2024-12-01 19:39:46', '2024-12-02 14:21:46', 0),
(7, 'Virgie Efhan', 'virgie@gmail.com', 'student', '$2y$10$UxrFE.qDF7HcQFPK9wEK2.Lf.n1691oGrSF0cHLUW2skBjIelhfnu', 'St2211600129', '2024-12-02 18:09:55', '2024-12-02 18:09:55', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_transactions`
--

CREATE TABLE `user_transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` enum('borrowed','returned') NOT NULL,
  `book_id` int(11) NOT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`ActivityLogID`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `isbn` (`isbn`),
  ADD UNIQUE KEY `accession_number` (`accession_number`);

--
-- Indexes for table `book_categories`
--
ALTER TABLE `book_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `book_category_association`
--
ALTER TABLE `book_category_association`
  ADD PRIMARY KEY (`book_id`,`category_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `borrow_records`
--
ALTER TABLE `borrow_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_transactions`
--
ALTER TABLE `user_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `book_id` (`book_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `ActivityLogID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `book_categories`
--
ALTER TABLE `book_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `borrow_records`
--
ALTER TABLE `borrow_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user_transactions`
--
ALTER TABLE `user_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `book_category_association`
--
ALTER TABLE `book_category_association`
  ADD CONSTRAINT `book_category_association_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`),
  ADD CONSTRAINT `book_category_association_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `book_categories` (`id`);

--
-- Constraints for table `borrow_records`
--
ALTER TABLE `borrow_records`
  ADD CONSTRAINT `borrow_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `borrow_records_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_transactions`
--
ALTER TABLE `user_transactions`
  ADD CONSTRAINT `user_transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `user_transactions_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`);

DELIMITER $$
--
-- Events
--
CREATE DEFINER=`root`@`localhost` EVENT `update_fines` ON SCHEDULE EVERY 5 MINUTE STARTS '2024-12-03 01:30:49' ON COMPLETION NOT PRESERVE ENABLE DO UPDATE borrow_records
SET fine_amount = fine_amount + 5
WHERE return_date IS NULL AND TIMESTAMPDIFF(MINUTE, due_date, NOW()) > 0$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
