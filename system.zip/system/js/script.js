// Wait for the document to be fully loaded
document.addEventListener('DOMContentLoaded', function () {

    // Handle the user registration form
    const registrationForm = document.getElementById('registrationForm');
    if (registrationForm) {
        registrationForm.addEventListener('submit', function (event) {
            event.preventDefault();
            let formData = new FormData(registrationForm);
            let errors = validateForm(formData);
            if (errors.length === 0) {
                submitForm(formData);
            } else {
                alert(errors.join("\n"));
            }
        });
    }

    // Handle the book management form (for adding/editing books)
    const manageBooksForm = document.getElementById('manageBooksForm');
    if (manageBooksForm) {
        manageBooksForm.addEventListener('submit', function (event) {
            event.preventDefault();
            let formData = new FormData(manageBooksForm);
            let errors = validateBookForm(formData);
            if (errors.length === 0) {
                submitBookForm(formData);
            } else {
                alert(errors.join("\n"));
            }
        });
    }

    // Book search functionality (AJAX)
    const searchInput = document.getElementById('bookSearchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function () {
            let query = searchInput.value;
            searchBooks(query);
        });
    }
    
    // Logout functionality
    const logoutButton = document.getElementById('logoutButton');
    if (logoutButton) {
        logoutButton.addEventListener('click', function () {
            logout();
        });
    }
});

// Validate user registration form
function validateForm(formData) {
    let errors = [];
    if (!formData.get('email') || !validateEmail(formData.get('email'))) {
        errors.push('Please enter a valid email address.');
    }
    if (!formData.get('password') || formData.get('password').length < 6) {
        errors.push('Password must be at least 6 characters long.');
    }
    return errors;
}

// Validate email format
function validateEmail(email) {
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailPattern.test(email);
}

// Submit the user registration form via AJAX
function submitForm(formData) {
    fetch('register_user.php', {
        method: 'POST',
        body: formData,
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Registration successful!');
            window.location.href = 'login.php'; // Redirect to login page
        } else {
            alert('Registration failed: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while processing the registration.');
    });
}

// Validate book form (for adding/editing books)
function validateBookForm(formData) {
    let errors = [];
    if (!formData.get('title') || formData.get('title').length < 3) {
        errors.push('Book title must be at least 3 characters long.');
    }
    if (!formData.get('author') || formData.get('author').length < 3) {
        errors.push('Book author must be at least 3 characters long.');
    }
    return errors;
}

// Submit the book form via AJAX
function submitBookForm(formData) {
    fetch('manage_books.php', {
        method: 'POST',
        body: formData,
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Book added/updated successfully!');
            location.reload(); // Reload the page to show updated books list
        } else {
            alert('Book management failed: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while processing the book management.');
    });
}

// AJAX search for books
function searchBooks(query) {
    fetch('search_books.php?query=' + encodeURIComponent(query))
        .then(response => response.json())
        .then(data => {
            const bookList = document.getElementById('bookList');
            bookList.innerHTML = ''; // Clear previous results
            data.books.forEach(book => {
                const bookItem = document.createElement('li');
                bookItem.textContent = `${book.title} by ${book.author}`;
                bookList.appendChild(bookItem);
            });
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while searching for books.');
        });
}

// Logout function (AJAX)
function logout() {
    fetch('logout.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.href = 'login.php'; // Redirect to login page
            } else {
                alert('Logout failed: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred during logout.');
        });
}
