<?php
// Database connection settings
$host = 'localhost'; // Can also use 127.0.0.1
$dbname = 'efhan';     // Your database name
$username = 'root';  // Your database username
$password = '';      // Your database password (empty for local dev)

try {
    // Establish PDO connection with utf8mb4 character set
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    
    // Set the PDO error mode to exception and enable exception handling
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Optional: Set the default fetch mode to associative arrays (fetch all data as arrays)
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    // Log the error to a file
    error_log("Database connection failed: " . $e->getMessage(), 3, 'error_log.txt');
    
    // Show a generic message to the user and prevent sensitive information leak
    die("Sorry, we're experiencing technical difficulties. Please try again later.");
}
?>
