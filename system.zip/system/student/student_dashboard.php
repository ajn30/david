<?php 
session_start();
require_once '../db.php';

// Check if the user is logged in
if (!isset($_SESSION['user']) || !isset($_SESSION['user']['id'])) {
    // Redirect to login page if the session is not set
    header('Location: ../auth/login.php');
    exit;
}

$userId = $_SESSION['user']['id'];  // Get the logged-in user's ID

// Fetch the fines of the student based on overdue books
$stmt = $pdo->prepare("SELECT SUM(DATEDIFF(CURDATE(), borrow_records.due_date) * 1) AS total_fines FROM borrow_records WHERE borrow_records.UserID = ? AND borrow_records.return_date IS NULL AND DATEDIFF(CURDATE(), borrow_records.due_date) > 0");
$stmt->execute([$userId]);
$fines = $stmt->fetch(PDO::FETCH_ASSOC);
$totalFines = $fines['total_fines'] ? $fines['total_fines'] : 0;  // If no fines, set to 0

// Fetch borrow history of the student
$stmt = $pdo->prepare("SELECT borrow_records.RecordID, libraryresources.Title, borrow_records.BorrowDate, borrow_records.due_date, borrow_records.return_date FROM borrow_records JOIN libraryresources ON borrow_records.ResourceID = libraryresources.ResourceID WHERE borrow_records.UserID = ? ORDER BY borrow_records.BorrowDate DESC");
$stmt->execute([$userId]);
$borrowHistory = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle search functionality
$searchResults = [];
if (isset($_GET['search'])) {
    $searchQuery = '%' . $_GET['search'] . '%';
    $stmt = $pdo->prepare("SELECT ResourceID, Title, Author, Category, Available_quantity FROM libraryresources WHERE Title LIKE ? OR Author LIKE ? OR Category LIKE ?");
    $stmt->execute([$searchQuery, $searchQuery, $searchQuery]);
    $searchResults = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>

    <!-- Bootstrap 5 CDN for CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqN5to8kSM+KnujsTM1Xf3kF5i6G7tu7zOe5w0F6Bz6uDkzZ6gK5I5u6g" crossorigin="anonymous">
    <link rel="stylesheet" href="../assets/css/style.css">
        <style>
            body {
    background-color: #f0f2f5;
    font-family: 'Arial', sans-serif;
    color: #333;
}

.dashboard-header {
    background-color: #00796b; /* Muted teal */
    color: white;
    padding: 30px;
    border-radius: 10px;
    margin-bottom: 30px;
    box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
}

.dashboard-header h1 {
    font-size: 2.2rem;
    font-weight: 600;
}

.dashboard-card {
    border-radius: 12px;
    box-shadow: 0px 6px 15px rgba(0, 0, 0, 0.1);
    background-color: #fff;
    margin-bottom: 20px;
}

.card-body {
    padding: 25px;
    background-color: #ffffff;
}

.table th, .table td {
    vertical-align: middle;
    text-align: center;
}

.card-header {
    background-color: #00796b; /* Muted teal */
    color: white;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    font-weight: 600;
    padding: 15px;
}

.btn-custom {
    background-color: #00796b; /* Muted teal */
    color: white;
    font-weight: 600;
}

.btn-custom:hover {
    background-color: #004d40; /* Darker teal on hover */
}

.profile-img {
    border-radius: 50%;
    max-width: 120px;
    margin-bottom: 15px;
}

.section-title {
    font-size: 1.75rem;
    font-weight: 600;
    color: #00796b; /* Muted teal */
    margin-bottom: 20px;
}

.card-footer {
    background-color: #f0f2f5;
    padding: 15px;
    text-align: center;
    border-bottom-left-radius: 12px;
    border-bottom-right-radius: 12px;
}

.card-footer a {
    color: #00796b;
    font-weight: 600;
    text-decoration: none;
}

.card-footer a:hover {
    text-decoration: underline;
}

/* Hover Effects */
.card-custom {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.card-custom:hover {
    transform: translateY(-8px);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
}

/* Profile Sidebar */
.profile-sidebar {
    background-color: #ffffff;
    padding: 25px;
    box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
    border-radius: 12px;
    margin-bottom: 20px;
}

.profile-sidebar .profile-name {
    font-size: 1.5rem;
    font-weight: 600;
    color: #00796b; /* Muted teal */
}

.profile-sidebar .profile-details {
    font-size: 1rem;
    color: #666;
}

.profile-sidebar .btn-custom {
    width: 100%;
    margin-bottom: 10px;
}

/* Search Bar */
.search-bar input {
    border-radius: 10px;
    padding: 10px;
    border: 1px solid #ddd;
    width: 100%;
}

.search-bar button {
    border-radius: 10px;
    padding: 10px 15px;
    background-color: #00796b;
    color: white;
    border: none;
    font-weight: 600;
}

.search-bar button:hover {
    background-color: #004d40; /* Darker teal on hover */
}

/* Table Styles */
.table-striped tbody tr:nth-of-type(odd) {
    background-color: #f9f9f9;
}

.table-striped tbody tr:nth-of-type(even) {
    background-color: #ffffff;
}

.table-bordered th, .table-bordered td {
    border: 1px solid #ddd;
}

/* Card with Hover */
.borrow-card {
    transition: all 0.3s ease;
}

.borrow-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
}

.borrow-card .card-header {
    background-color: #004d40; /* Darker teal */
}

.borrow-card .card-body {
    background-color: #ffffff;
    padding: 20px;
}

/* Responsive Media Queries */
@media (max-width: 768px) {
    .profile-sidebar {
        padding: 20px;
    }

    .dashboard-header h1 {
        font-size: 1.8rem;
    }

    .section-title {
        font-size: 1.5rem;
    }

    .table th, .table td {
        padding: 10px;
        font-size: 14px;
    }
        </style>
</head>
<body class="bg-light">

<div class="container-fluid">
    <div class="row">

        <!-- Sidebar Section -->
        <div class="col-lg-3 col-md-4 bg-white p-4 shadow-sm rounded-3">
            <div class="text-center mb-4">
                <img src="path_to_your_profile_picture.jpg" alt="Profile Picture" class="profile-img">
                <h4><?php echo htmlspecialchars($_SESSION['user']['name']); ?></h4>
                <p><small>Student ID: <?php echo $_SESSION['user']['id']; ?></small></p>
                <p class="text-muted">Welcome back to your student dashboard</p>
            </div>
            
            <div class="d-flex flex-column align-items-center">
                <a href="../auth/logout.php" class="btn btn-danger mb-3 w-100 btn-custom">Logout</a>
                <a href="edit_profile.php" class="btn btn-primary mb-3 w-100 btn-custom">Edit Profile</a>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="col-lg-9 col-md-8 p-4">

            <!-- Header Section -->
            <div class="dashboard-header">
                <h1>Student Dashboard</h1>
                <p>Here you can view your fines, borrow history, and search for resources.</p>
            </div>

            <!-- Fines Overview -->
            <div class="card dashboard-card mb-4">
                <div class="card-header">
                    <i class="bi bi-cash-stack"></i> <strong>Total Fines</strong>
                </div>
                <div class="card-body text-center">
                    <h2 class="display-4 text-danger">PHP <?php echo number_format($totalFines, 2); ?></h2>
                    <p class="text-muted">You have overdue books. Please return them as soon as possible to avoid further fines.</p>
                </div>
            </div>

            <!-- Borrow History Section -->
            <div class="card dashboard-card mb-4">
                <div class="card-header">
                    <i class="bi bi-book"></i> <strong>Borrow History</strong>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Book Title</th>
                                <th>Borrow Date</th>
                                <th>Due Date</th>
                                <th>Return Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($borrowHistory): ?>
                                <?php foreach ($borrowHistory as $record): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($record['Title']); ?></td>
                                        <td><?php echo date('F j, Y', strtotime($record['BorrowDate'])); ?></td>
                                        <td><?php echo date('F j, Y', strtotime($record['due_date'])); ?></td>
                                        <td>
                                            <?php 
                                            if ($record['return_date']) {
                                                echo date('F j, Y', strtotime($record['return_date']));
                                            } else {
                                                echo "Not Returned Yet";
                                            }
                                            ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="text-center">No borrow history found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Search Resources Section -->
            <div class="card dashboard-card mb-4">
                <div class="card-header">
                    <i class="bi bi-search"></i> <strong>Search Resources</strong>
                </div>
                <div class="card-body">
                    <form method="GET" class="d-flex">
                        <input type="text" name="search" class="form-control" placeholder="Search by Title, Category, or Author" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                        <button type="submit" class="btn btn-outline-primary ms-2">Search</button>
                    </form>

                    <!-- Search Results -->
                    <?php if (!empty($searchResults)): ?>
                        <div class="mt-4">
                            <h5>Search Results</h5>
                            <table class="table table-hover mt-3">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Author</th>
                                        <th>Category</th>
                                        <th>Availability</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($searchResults as $resource): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($resource['Title']); ?></td>
                                            <td><?php echo htmlspecialchars($resource['Author']); ?></td>
                                            <td><?php echo htmlspecialchars($resource['Category']); ?></td>
                                            <td>
                                                <?php echo $resource['Available_quantity'] > 0 ? 'Available' : 'Not Available'; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php elseif (isset($_GET['search'])): ?>
                        <div class="alert alert-warning mt-4">No resources found matching your search.</div>
                    <?php endif; ?>
                </div>
            </div>

        </div>

    </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pzjw8f+ua7Kw1TIq0dpU6RkFuYg9zjF6ptfJ3NO6E1JbLfHnX5Z+aZLR3IjyIh+m" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.js"></script>

</body>
</html>
