<?php
session_start();
require_once '../db.php';

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    header('Location: ../auth/login.php');
    exit;
}

// Initialize search query
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Prepare the SQL query to search for books by title, author, or genre
$stmt = $pdo->prepare("
    SELECT id, title, author, genre, isbn, accession_number, available_quantity 
    FROM books 
    WHERE title LIKE :search 
    OR author LIKE :search
    OR genre LIKE :search
");
$stmt->execute(['search' => '%' . $search . '%']);
$books = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search Books</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h1>Search Books</h1>
    
    <!-- Search Form -->
    <form action="search_books.php" method="GET">
        <input type="text" name="search" placeholder="Enter book title, author, or genre" value="<?php echo htmlspecialchars($search); ?>" required>
        <button type="submit">Search</button>
    </form>

    <h2>Search Results</h2>
    
    <?php if ($books): ?>
        <!-- Display Books Found -->
        <table>
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Genre</th>
                    <th>ISBN</th>
                    <th>Accession Number</th>
                    <th>Availability</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($books as $book): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($book['title']); ?></td>
                                <td><?php echo htmlspecialchars($book['author']); ?></td>
                                <td><?php echo htmlspecialchars($book['genre']); ?></td>
                                <td><?php echo htmlspecialchars($book['isbn']); ?></td>
                                <td><?php echo htmlspecialchars($book['accession_number']); ?></td>
                                <td>
                                    <?php if ($book['available_quantity'] > 0): ?>
                                        <?php echo htmlspecialchars($book['available_quantity']); ?>
                                    <?php else: ?>
                                        Unavailable
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
        </table>
    <?php else: ?>
        <p>No books found matching your search.</p>
    <?php endif; ?>

    <!-- Link back to dashboard -->
    <br>
    <a href="student_dashboard.php">Back to Dashboard</a>
</body>
</html>
