<footer>
    <p>&copy; <?php echo date("Y"); ?> Bright Future High School Library Management System. All rights reserved.</p>
</footer>
</body>
</html>
