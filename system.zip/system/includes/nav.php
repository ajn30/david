<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user'])) {
    header('Location: ../auth/login.php');
    exit();
}

$userType = $_SESSION['user']['user_type'];
?>
<nav>
    <ul>
        <li><a href="../dashboard.php">Dashboard</a></li>
        <?php if ($userType === 'admin'): ?>
            <li><a href="../admin/manage_books.php">Manage Books</a></li>
            <li><a href="../admin/register.php">Register User</a></li>
        <?php endif; ?>
        <li><a href="../auth/logout.php">Logout</a></li>
    </ul>
</nav>
