<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Management System</title>
    <link rel="stylesheet" href="assets/css/style.css">  <!-- Add your custom styles here -->
    <!-- Optional: Add Bootstrap for a cleaner UI -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <header class="bg-primary text-white py-4">
        <div class="container text-center">
            <h1>Welcome to Bright Future High School Library</h1>
        </div>
    </header>

    <nav class="bg-light py-2">
        <div class="container">
            <?php if (isset($_SESSION['user'])): ?>
                <p>Welcome, <?php echo htmlspecialchars($_SESSION['user']['name']); ?>!</p>
                <?php if ($_SESSION['user']['user_type'] === 'admin'): ?>
                    <a href="admin/dashboard.php" class="btn btn-info">Admin Dashboard</a>
                <?php else: ?>
                    <a href="user/dashboard.php" class="btn btn-info">My Dashboard</a>
                <?php endif; ?>
                <a href="auth/logout.php" class="btn btn-danger">Logout</a>
            <?php else: ?>
                <a href="auth/login.php" class="btn btn-success">Login</a>
            <?php endif; ?>
        </div>
    </nav>

    <main class="container my-5">
        <section class="mb-4">
            <h2>About the Library</h2>
            <p>
                Bright Future High School's library offers over 10,000 resources, 
                including academic textbooks, fiction, reference materials, and periodicals.
                Our new Library Management System helps automate user registration, 
                borrowing, returning, and reporting.
            </p>
        </section>

        <section>
            <h2>Features</h2>
            <ul>
                <li>User-friendly management for students, staff, and administrators</li>
                <li>Real-time book availability</li>
                <li>Overdue tracking with automatic fine calculation</li>
                <li>Search and filter functionalities for books and users</li>
                <li>Detailed reporting and analytics</li>
            </ul>
        </section>
    </main>

    <footer class="bg-dark text-white py-3">
        <div class="container text-center">
            <p>&copy; 2024 Bright Future High School Library</p>
        </div>
    </footer>

    <!-- Optional: Bootstrap JS for additional interactivity (if needed) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
