<?php
// Include database connection
include($_SERVER['DOCUMENT_ROOT'].'/library_management_system/db.php');

// Get the ResourceID from the GET parameter
$resourceID = isset($_GET['ResourceID']) ? $_GET['ResourceID'] : '';

// Fetch the resource data if ResourceID is provided
if ($resourceID) {
    try {
        // Prepare SQL query to fetch the resource data
        $sql = "SELECT * FROM libraryresources WHERE ResourceID = :resourceID";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':resourceID', $resourceID);
        $stmt->execute();
        $resource = $stmt->fetch(PDO::FETCH_ASSOC);

        // If no resource found
        if (!$resource) {
            echo "Resource not found!";
            exit;
        }
    } catch (PDOException $e) {
        echo "Error fetching resource: " . htmlspecialchars($e->getMessage());
        exit;
    }
}

// Update resource data when the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get updated values from the form
    $title = $_POST['title'];
    $accessionNumber = $_POST['accessionNumber'];
    $category = $_POST['category'];
    $acquisitionYear = $_POST['acquisitionYear'];
    $availabilityStatus = $_POST['availabilityStatus'];

    try {
        // Prepare SQL query to update the resource data
        $sql = "UPDATE libraryresources 
                SET Title = :title, AccessionNumber = :accessionNumber, Category = :category, 
                    AcquisitionYear = :acquisitionYear, AvailabilityStatus = :availabilityStatus 
                WHERE ResourceID = :resourceID";
        $stmt = $pdo->prepare($sql);
        
        // Bind parameters and execute
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':accessionNumber', $accessionNumber);
        $stmt->bindParam(':category', $category);
        $stmt->bindParam(':acquisitionYear', $acquisitionYear);
        $stmt->bindParam(':availabilityStatus', $availabilityStatus);
        $stmt->bindParam(':resourceID', $resourceID);
        $stmt->execute();

        // Success message
        echo "<p>Resource updated successfully!</p>";
    } catch (PDOException $e) {
        echo "Error updating resource: " . htmlspecialchars($e->getMessage());
    }
}

// Close database connection
$pdo = null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Resource</title>
</head>
<body>

    <h1>Edit Resource</h1>
    
    <!-- Form to edit resource -->
    <form method="POST" action="edit_resource.php?ResourceID=<?php echo $resourceID; ?>">
        <label for="title">Title:</label><br>
        <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($resource['Title']); ?>" required><br><br>

        <label for="accessionNumber">Accession Number:</label><br>
        <input type="text" id="accessionNumber" name="accessionNumber" value="<?php echo htmlspecialchars($resource['AccessionNumber']); ?>" required><br><br>

        <label for="category">Category:</label><br>
        <select name="category" id="category">
            <option value="Book" <?php echo ($resource['Category'] == 'Book') ? 'selected' : ''; ?>>Book</option>
            <option value="MediaResource" <?php echo ($resource['Category'] == 'MediaResource') ? 'selected' : ''; ?>>Media</option>
            <option value="Periodical" <?php echo ($resource['Category'] == 'Periodical') ? 'selected' : ''; ?>>Periodical</option>
        </select><br><br>

        <label for="acquisitionYear">Acquisition Year:</label><br>
        <input type="text" id="acquisitionYear" name="acquisitionYear" value="<?php echo htmlspecialchars($resource['AcquisitionYear']); ?>" required><br><br>

        <label for="availabilityStatus">Availability Status:</label><br>
        <select name="availabilityStatus" id="availabilityStatus">
            <option value="Available" <?php echo ($resource['AvailabilityStatus'] == 'Available') ? 'selected' : ''; ?>>Available</option>
            <option value="Unavailable" <?php echo ($resource['AvailabilityStatus'] == 'Unavailable') ? 'selected' : ''; ?>>Unavailable</option>
        </select><br><br>

        <input type="submit" value="Update Resource">
    </form>

    <!-- Back to the previous page -->
    <br><br>
    <a href="view_total_resources.php">Back to Resources List</a>

</body>
</html>
