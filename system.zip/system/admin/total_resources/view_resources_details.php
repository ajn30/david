<?php
// Include database connection
include($_SERVER['DOCUMENT_ROOT'].'/library_management_system/db.php');

// Check if 'ResourceID' is passed via URL
if (isset($_GET['ResourceID'])) {
    $resourceID = $_GET['ResourceID'];

    // Query to fetch resource details from libraryresources table
    $query = "SELECT lr.ResourceID, lr.Title, lr.AccessionNumber, lr.Category, lr.AcquisitionYear, lr.AvailabilityStatus, 
              mr.Format, mr.Runtime, mr.MediaType, p.ISSN, p.Volume, p.Issue, p.PublicationDate
              FROM libraryresources lr
              LEFT JOIN mediaresources mr ON lr.ResourceID = mr.ResourceID
              LEFT JOIN periodicals p ON lr.ResourceID = p.ResourceID
              WHERE lr.ResourceID = :resourceID";

    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':resourceID', $resourceID);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        // Fetch the resource details
        $row = $stmt->fetch();

        echo "<h1>Resource Details</h1>";
        echo "<table border='1'>
                <tr>
                    <th>Title</th>
                    <td>" . $row['Title'] . "</td>
                </tr>
                <tr>
                    <th>Accession Number</th>
                    <td>" . $row['AccessionNumber'] . "</td>
                </tr>
                <tr>
                    <th>Category</th>
                    <td>" . $row['Category'] . "</td>
                </tr>
                <tr>
                    <th>Acquisition Year</th>
                    <td>" . $row['AcquisitionYear'] . "</td>
                </tr>
                <tr>
                    <th>Availability Status</th>
                    <td>" . $row['AvailabilityStatus'] . "</td>
                </tr>";

        // Display additional details based on the category
        if ($row['Category'] == 'MediaResource') {
            echo "<tr>
                    <th>Format</th>
                    <td>" . $row['Format'] . "</td>
                  </tr>
                  <tr>
                    <th>Runtime</th>
                    <td>" . $row['Runtime'] . " minutes</td>
                  </tr>
                  <tr>
                    <th>Media Type</th>
                    <td>" . $row['MediaType'] . "</td>
                  </tr>";
        } elseif ($row['Category'] == 'Periodical') {
            echo "<tr>
                    <th>ISSN</th>
                    <td>" . $row['ISSN'] . "</td>
                  </tr>
                  <tr>
                    <th>Volume</th>
                    <td>" . $row['Volume'] . "</td>
                  </tr>
                  <tr>
                    <th>Issue</th>
                    <td>" . $row['Issue'] . "</td>
                  </tr>
                  <tr>
                    <th>Publication Date</th>
                    <td>" . $row['PublicationDate'] . "</td>
                  </tr>";
        }

        echo "</table>";
    } else {
        echo "No resource found with this ID.";
    }

    // Close database connection
    $pdo = null;
} else {
    echo "No resource ID provided.";
}
?>
