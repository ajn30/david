<?php
session_start();  // Start the session

// Include the database connection file
require_once('C:/xampp/htdocs/system/db.php');

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    // Redirect to login page if not logged in
    header('Location: ../auth/login.php');
    exit;
}

// Get the selected category from the GET parameter (if any)
$category = isset($_GET['category']) ? $_GET['category'] : '';

// Prepare the SQL query based on the category filter
$sql = "SELECT lr.ResourceID, lr.Title, lr.AccessionNumber, lr.Category, lr.AcquisitionYear, lr.AvailabilityStatus 
        FROM libraryresources lr";

// If a category is selected, add a WHERE clause
if ($category) {
    $sql .= " WHERE lr.Category = :category";
}

try {
    // Prepare the query
    $stmt = $pdo->prepare($sql);

    // If a category is selected, bind the category parameter
    if ($category) {
        $stmt->bindParam(':category', $category);
    }

    // Execute the query
    $stmt->execute();
    $result = $stmt->fetchAll();
} catch (PDOException $e) {
    // Handle database connection errors
    echo "Error: " . $e->getMessage();
    exit;
}

// Download CSV functionality
if (isset($_GET['download'])) {
    // Create CSV file
    $filename = "library_resources.csv";
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $output = fopen('php://output', 'w');

    // Add the headers to the CSV file
    fputcsv($output, ['Resource ID', 'Title', 'Accession Number', 'Category', 'Acquisition Year', 'Availability Status']);

    // Add data to the CSV file
    foreach ($result as $row) {
        fputcsv($output, $row);
    }
    fclose($output);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Library Resources</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        @media print {
            body {
                font-family: Arial, sans-serif;
            }
            table {
                width: 100%;
                border-collapse: collapse;
            }
            th, td {
                border: 1px solid #000;
                padding: 8px;
                text-align: left;
            }
            th {
                background-color: #f2f2f2;
            }
            .no-print {
                display: none;
            }
        }
    </style>
</head>
<body>

<div class="container my-4">
    <h1>Library Resources</h1>

    <!-- Filter form for category -->
    <form method="GET" action="view_total_resources.php" class="form-inline mb-3">
        <label for="category" class="mr-2">Filter by Category:</label>
        <select name="category" id="category" class="form-control mr-3">
            <option value="">All</option>
            <option value="Book" <?php echo $category == 'Book' ? 'selected' : ''; ?>>Book</option>
            <option value="MediaResource" <?php echo $category == 'MediaResource' ? 'selected' : ''; ?>>Media</option>
            <option value="Periodical" <?php echo $category == 'Periodical' ? 'selected' : ''; ?>>Periodical</option>
        </select>
        <button type="submit" class="btn btn-primary">Filter</button>
    </form>

    <!-- Print button (hidden when printing) -->
    <button class="btn btn-secondary no-print" onclick="window.print()">Print</button>

    <!-- Download CSV button -->
    <a href="view_total_resources.php?<?php echo isset($_GET['category']) ? 'category=' . $_GET['category'] : ''; ?>&download=true" class="btn btn-success no-print">Download CSV</a>

    <?php
    // Check if the query returns any results
    if (count($result) > 0) {
        echo "<table class='table table-bordered table-striped mt-3'>
                <thead>
                    <tr>
                        <th>Resource ID</th>
                        <th>Title</th>
                        <th>Accession Number</th>
                        <th>Category</th>
                        <th>Acquisition Year</th>
                        <th>Availability Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>";

        // Fetch and display each row of data
        foreach ($result as $row) {
            echo "<tr>
                    <td>" . htmlspecialchars($row['ResourceID']) . "</td>
                    <td>" . htmlspecialchars($row['Title']) . "</td>
                    <td>" . htmlspecialchars($row['AccessionNumber']) . "</td>
                    <td>" . htmlspecialchars($row['Category']) . "</td>
                    <td>" . htmlspecialchars($row['AcquisitionYear']) . "</td>
                    <td>" . htmlspecialchars($row['AvailabilityStatus']) . "</td>
                    <td>
                        <a href='edit_resource.php?ResourceID=" . $row['ResourceID'] . "' class='btn btn-warning btn-sm'>Edit</a> | 
                        <a href='delete_resource.php?ResourceID=" . $row['ResourceID'] . "' onclick='return confirm(\"Are you sure you want to delete this resource?\")' class='btn btn-danger btn-sm'>Delete</a>
                    </td>
                  </tr>";
        }
        echo "</tbody></table>";
    } else {
        echo "<p>No resources found!</p>";
    }

    // Close database connection
    $pdo = null;
    ?>

</div>

<!-- Bootstrap JS (Optional, for better interactivity) -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
