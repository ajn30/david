<?php
// Include database connection
include($_SERVER['DOCUMENT_ROOT'].'/library_management_system/db.php');

// Get the ResourceID from the GET parameter
$resourceID = isset($_GET['ResourceID']) ? $_GET['ResourceID'] : '';

// If no ResourceID is provided, redirect or show an error
if (!$resourceID) {
    echo "Resource ID not provided!";
    exit;
}

// Delete the resource from the database
try {
    // Prepare SQL query to delete the resource
    $sql = "DELETE FROM libraryresources WHERE ResourceID = :resourceID";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':resourceID', $resourceID);
    $stmt->execute();

    // Success message
    echo "<p>Resource deleted successfully!</p>";
    
    // Optionally, redirect back to the resources list page after deletion
    header("Location: view_total_resources.php");
    exit;
} catch (PDOException $e) {
    echo "Error deleting resource: " . htmlspecialchars($e->getMessage());
}

// Close database connection
$pdo = null;
?>
