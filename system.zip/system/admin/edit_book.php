<?php
session_start();
require_once '../db.php';  // Ensure this path is correct
require_once '../includes/helpers.php';

// Check if the user is an admin
if (!isset($_SESSION['user']) || $_SESSION['user']['user_type'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

// Ensure $pdo is initialized (use $pdo instead of $conn)
if (!isset($pdo)) {
    die('Database connection failed');
}

// Get the book ID from the URL
if (isset($_GET['id'])) {
    $bookId = $_GET['id'];

    // Fetch book details using PDO
    $stmt = $pdo->prepare("SELECT * FROM books WHERE id = :id");
    $stmt->bindParam(':id', $bookId, PDO::PARAM_INT);
    $stmt->execute();
    $book = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Update book details
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $author = $_POST['author'];
    $publisher = $_POST['publisher'];
    $genre = $_POST['genre'];
    $isbn = $_POST['isbn'];
    $accession_number = $_POST['accession_number'];

    // Prepare the update statement
    $stmt = $pdo->prepare("UPDATE books SET title = ?, author = ?, publisher = ?, genre = ?, isbn = ?, accession_number = ? WHERE id = ?");
    $stmt->execute([$title, $author, $publisher, $genre, $isbn, $accession_number, $bookId]);

    if ($stmt->rowCount() > 0) {
        $_SESSION['success'] = "Book updated successfully!";

        // Log the update action in the activity log table
        $user_id = $_SESSION['user']['id']; // Assuming the user ID is stored in session
        $log_query = "INSERT INTO activity_log (UserID, ActionType, ResourceType, ResourceID, Description, IP_Address) 
                      VALUES (?, ?, ?, ?, ?, ?)";
        $log_stmt = $pdo->prepare($log_query);
        $ip_address = $_SERVER['REMOTE_ADDR'];
        $description = "Book details updated: " . $book['title']; // Example description for updating book
        $log_stmt->execute([
            $user_id,
            'Update Book', 
            'Book',
            $book['id'],
            $description,
            $ip_address
        ]);

        header('Location: manage_books.php');
        exit();
    } else {
        $_SESSION['error'] = "Failed to update book.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Book</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header>
        <h1>Edit Book</h1>
    </header>
    <nav>
        <a href="manage_books.php">Manage Books</a> | <a href="../auth/logout.php">Logout</a>
    </nav>
    <main>
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert error"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>

        <form method="POST" action="edit_book.php?id=<?php echo $book['id']; ?>">
            <label for="title">Title:</label>
            <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($book['title']); ?>" required>

            <label for="author">Author:</label>
            <input type="text" id="author" name="author" value="<?php echo htmlspecialchars($book['author']); ?>" required>

            <label for="publisher">Publisher:</label>
            <input type="text" id="publisher" name="publisher" value="<?php echo htmlspecialchars($book['publisher']); ?>" required>

            <label for="genre">Genre:</label>
            <input type="text" id="genre" name="genre" value="<?php echo htmlspecialchars($book['genre']); ?>" required>

            <label for="isbn">ISBN:</label>
            <input type="text" id="isbn" name="isbn" value="<?php echo htmlspecialchars($book['isbn']); ?>" required>

            <label for="accession_number">Accession Number:</label>
            <input type="text" id="accession_number" name="accession_number" value="<?php echo htmlspecialchars($book['accession_number']); ?>" required>

            <button type="submit">Update Book</button>
        </form>
    </main>
</body>
</html>
