<?php
session_start();
require_once '../db.php';

// Check if the user is an admin
if (!isset($_SESSION['user']) || $_SESSION['user']['user_type'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

// Handle filter selection
$userTypeFilter = isset($_POST['user_type_filter']) ? $_POST['user_type_filter'] : '';

// Fetch all users along with their borrowing history and fines, applying the filter if selected
$query = "
    SELECT 
        u.id, u.Name, u.email, u.User_type, 
        GROUP_CONCAT(bt.ResourceID) AS borrowing_history,  -- Concatenates borrowed resource IDs
        SUM(bt.FineAmount) AS total_fines
    FROM users u
    LEFT JOIN borrowingtransactions bt ON u.id = bt.UserID
";

// Apply the filter if a user type is selected
if ($userTypeFilter) {
    $query .= " WHERE u.User_type = :user_type";
}

$query .= " GROUP BY u.id";
$stmt = $pdo->prepare($query);

// If filtering, bind the user type
if ($userTypeFilter) {
    $stmt->bindParam(':user_type', $userTypeFilter);
}

$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle user deletion
if (isset($_POST['delete'])) {
    $userId = $_POST['user_id'];
    
    // Fetch the user details (name and email) for the log
    $stmt = $pdo->prepare("SELECT Name, email FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Delete the user from the database
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$userId]);

    // Log the deletion action
    $log_query = "INSERT INTO activity_log (UserID, ActionType, ResourceType, ResourceID, Description, IP_Address) 
                  VALUES (?, ?, ?, ?, ?, ?)";
    $log_stmt = $pdo->prepare($log_query);
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $description = "User deleted: " . $user['Name'] . " (Email: " . $user['email'] . ")";
    $log_stmt->execute([
        $_SESSION['user']['id'],  // Log the admin's user ID who performed the deletion
        'Delete User',            // Action type
        'User',                   // Resource type
        $userId,                  // Resource ID (the deleted user's ID)
        $description,             // Description of the action
        $ip_address               // IP address of the admin performing the action
    ]);
    
    // Redirect to refresh the page
    header('Location: manage_users.php'); // Refresh the page after deletion
    exit;
}

// Handle user update
if (isset($_POST['update'])) {
    $userId = $_POST['user_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $userType = $_POST['user_type'];

    // Update the user in the database
    $stmt = $pdo->prepare("UPDATE users SET Name = ?, email = ?, User_type = ? WHERE id = ?");
    $stmt->execute([$name, $email, $userType, $userId]);
    header('Location: manage_users.php'); // Refresh the page after update
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

    <div class="container mt-4">
        <!-- Back Button at the top -->
        <a href="admin_dashboard.php" class="btn btn-secondary mb-3">Back</a>

        <h1 class="mb-4">Manage Users</h1>

        <!-- Filter Form -->
        <form method="POST" action="" class="mb-3">
            <div class="row">
                <div class="col-md-4">
                    <label for="user_type_filter" class="form-label">Filter by User Type:</label>
                    <select name="user_type_filter" id="user_type_filter" class="form-select">
                        <option value="">-- All --</option>
                        <option value="admin" <?php if ($userTypeFilter == 'admin') echo 'selected'; ?>>Admin</option>
                        <option value="staff" <?php if ($userTypeFilter == 'staff') echo 'selected'; ?>>Staff</option>
                        <option value="faculty" <?php if ($userTypeFilter == 'faculty') echo 'selected'; ?>>Faculty</option>
                        <option value="student" <?php if ($userTypeFilter == 'student') echo 'selected'; ?>>Student</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary mt-4">Apply Filter</button>
                </div>
            </div>
        </form>

        <!-- Add New User Button -->
        <button onclick="openAddUserModal()" class="btn btn-success mb-4">Add New User</button>

        <!-- Existing Users Table -->
        <h2>Existing Users</h2>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>User Type</th>
                    <th>Borrowing History</th>
                    <th>Total Fines</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['Name']); ?></td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td><?php echo htmlspecialchars($user['User_type']); ?></td>
                        <td>
                            <pre><?php echo htmlspecialchars($user['borrowing_history']); ?></pre>
                        </td>
                        <td><?php echo number_format($user['total_fines'], 2); ?></td>
                        <td>
                            <!-- Edit Button -->
                            <button onclick="openEditModal(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['Name']); ?>', '<?php echo htmlspecialchars($user['email']); ?>', '<?php echo htmlspecialchars($user['User_type']); ?>')" class="btn btn-warning btn-sm">Edit</button>

                            <!-- Delete Button -->
                            <form action="" method="POST" style="display:inline;">
                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                <button type="submit" name="delete" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this user?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Modal for Editing User -->
    <div id="editUserModal" class="modal fade" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editUserModalLabel">Edit User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="" method="POST">
                        <input type="hidden" id="editUserId" name="user_id">
                        
                        <div class="mb-3">
                            <label for="name" class="form-label">Name:</label>
                            <input type="text" id="editName" name="name" class="form-control" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email:</label>
                            <input type="email" id="editEmail" name="email" class="form-control" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="user_type" class="form-label">User Type:</label>
                            <select id="editUserType" name="user_type" class="form-select" required>
                                <option value="student">Student</option>
                                <option value="faculty">Faculty</option>
                                <option value="staff">Staff</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                        
                        <button type="submit" name="update" class="btn btn-success">Update User</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for Adding New User -->
    <div id="addUserModal" class="modal fade" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addUserModalLabel">Add New User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="add_user.php" method="POST">
                        <div class="mb-3">
                            <label for="name" class="form-label">Name:</label>
                            <input type="text" id="addName" name="name" class="form-control" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email:</label>
                            <input type="email" id="addEmail" name="email" class="form-control" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="user_type" class="form-label">User Type:</label>
                            <select id="addUserType" name="user_type" class="form-select" required>
                                <option value="student">Student</option>
                                <option value="faculty">Faculty</option>
                                <option value="staff">Staff</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="password" class="form-label">Password:</label>
                            <input type="password" id="addPassword" name="password" class="form-control" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="membership_id" class="form-label">Membership ID:</label>
                            <input type="text" id="addMembershipId" name="membership_id" class="form-control" required>
                        </div>
                        
                        <button type="submit" class="btn btn-success">Add User</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5 JS and Dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Open the edit modal and populate the form
        function openEditModal(userId, userName, userEmail, userType) {
            document.getElementById('editUserId').value = userId;
            document.getElementById('editName').value = userName;
            document.getElementById('editEmail').value = userEmail;
            document.getElementById('editUserType').value = userType;
            var myModal = new bootstrap.Modal(document.getElementById('editUserModal'));
            myModal.show();
        }

        // Open the add user modal
        function openAddUserModal() {
            var myModal = new bootstrap.Modal(document.getElementById('addUserModal'));
            myModal.show();
        }
    </script>

</body>
</html>
