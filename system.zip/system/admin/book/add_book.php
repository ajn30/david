<?php
// Database connection
$servername = "localhost";
$username = "root"; // your database username
$password = ""; // your database password
$dbname = "efhan"; // your database name

try {
    // Create connection
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if the form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get input values from the form
        $title = $_POST['title'];
        $accessionNumber = $_POST['accessionNumber'];
        $author = $_POST['author'];
        $genre = $_POST['genre'];
        $isbn = $_POST['isbn'];
        $publisher = $_POST['publisher'];
        $edition = $_POST['edition'];
        $publicationDate = $_POST['publicationDate'];
        $quantity = $_POST['quantity'];
        $available_quantity = $_POST['available_quantity'];
        $acquisitionYear = date("Y"); // Current year for acquisition
        
        // Step 1: Insert book data into `libraryresources` table, including author and available quantity
        $stmt1 = $conn->prepare("INSERT INTO libraryresources (Title, AccessionNumber, Category, AcquisitionYear, AvailabilityStatus, Author, Available_quantity) 
                                 VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt1->execute([$title, $accessionNumber, 'Book', $acquisitionYear, 'Available', $author, $available_quantity]);

        // Get the last inserted ResourceID
        $resourceID = $conn->lastInsertId();

        // Step 2: Insert detailed book data into `books` table, including available quantity
        $stmt2 = $conn->prepare("INSERT INTO books (ResourceID, Title, Author, Genre, ISBN, Publisher, AccessionNumber, Edition, PublicationDate, Quantity, Available_Quantity)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt2->execute([ 
            $resourceID, $title, $author, $genre, $isbn, $publisher, $accessionNumber, 
            $edition, $publicationDate, $quantity, $available_quantity
        ]);

        // Redirect to the same page with a success message
        header("Location: add_book.php?success=1");
        exit();
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>

<!-- HTML Form to Add Book -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Book</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .card {
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 0.25rem rgba(38, 143, 255, 0.25);
        }
        .btn-primary {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        .btn-primary:hover {
            background-color: #004085;
            border-color: #003366;
        }
        .alert {
            border-radius: 10px;
        }
    </style>
</head>
<body>

<div class="container d-flex justify-content-center align-items-center min-vh-100">
    <div class="card p-4" style="width: 100%; max-width: 600px;">
        <h2 class="text-center mb-4">Add New Book</h2>

        <?php
        // Display success message if the form was successfully submitted
        if (isset($_GET['success']) && $_GET['success'] == 1) {
            echo "<div class='alert alert-success'>Book has been successfully added to the library!</div>";
        }
        ?>

        <form action="add_book.php" method="POST">
            <div class="mb-3">
                <label for="title" class="form-label">Title</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>

            <div class="mb-3">
                <label for="accessionNumber" class="form-label">Accession Number</label>
                <input type="text" class="form-control" id="accessionNumber" name="accessionNumber" required>
            </div>

            <div class="mb-3">
                <label for="author" class="form-label">Author</label>
                <input type="text" class="form-control" id="author" name="author" required>
            </div>

            <div class="mb-3">
                <label for="genre" class="form-label">Genre</label>
                <input type="text" class="form-control" id="genre" name="genre" required>
            </div>

            <div class="mb-3">
                <label for="isbn" class="form-label">ISBN</label>
                <input type="text" class="form-control" id="isbn" name="isbn" required>
            </div>

            <div class="mb-3">
                <label for="publisher" class="form-label">Publisher</label>
                <input type="text" class="form-control" id="publisher" name="publisher" required>
            </div>

            <div class="mb-3">
                <label for="edition" class="form-label">Edition</label>
                <input type="text" class="form-control" id="edition" name="edition" required>
            </div>

            <div class="mb-3">
                <label for="publicationDate" class="form-label">Publication Date</label>
                <input type="date" class="form-control" id="publicationDate" name="publicationDate" required>
            </div>

            <div class="mb-3">
                <label for="quantity" class="form-label">Quantity</label>
                <input type="number" class="form-control" id="quantity" name="quantity" required>
            </div>

            <div class="mb-3">
                <label for="available_quantity" class="form-label">Available Quantity</label>
                <input type="number" class="form-control" id="available_quantity" name="available_quantity" required>
            </div>

            <button type="submit" class="btn btn-primary w-100">Add Book</button>
        </form>
    </div>
</div>

<!-- Bootstrap 5 JS and Dependencies -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
