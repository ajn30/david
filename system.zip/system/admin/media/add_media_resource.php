<?php
// Include database connection file
require_once('../../db.php');  // Adjust the path as necessary

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the form data
    $title = $_POST['title'];
    $accessionNumber = $_POST['accession_number'];
    $acquisitionYear = $_POST['acquisition_year'];
    $format = $_POST['format'];
    $runtime = $_POST['runtime'];
    $mediaType = $_POST['media_type'];
    $author = $_POST['author'];
    $quantity = $_POST['quantity'];
    $availableQuantity = $quantity;  // Assuming available_quantity is the same as quantity when adding a new resource

    // Create a new PDO instance
    try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Start a transaction
        $conn->beginTransaction();

        // Insert into libraryresources table (including available_quantity)
        $stmt = $conn->prepare("INSERT INTO libraryresources (Title, AccessionNumber, Category, AcquisitionYear, AvailabilityStatus, AvailableQuantity) 
                               VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$title, $accessionNumber, 'MediaResource', $acquisitionYear, 'Available', $availableQuantity]);
        $resourceID = $conn->lastInsertId();  // Get the last inserted ResourceID

        // Insert into mediaresources table (including available_quantity)
        $stmt = $conn->prepare("INSERT INTO mediaresources (ResourceID, Title, Format, Runtime, MediaType, Author, Quantity, Available_Quantity) 
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$resourceID, $title, $format, $runtime, $mediaType, $author, $quantity, $availableQuantity]);

        // Log the addition of the new media resource
        $log_query = "INSERT INTO activity_log (UserID, ActionType, ResourceType, ResourceID, Description, IP_Address) 
                      VALUES (?, ?, ?, ?, ?, ?)";
        $log_stmt = $conn->prepare($log_query);
        $ip_address = $_SERVER['REMOTE_ADDR'];
        $description = "Media resource added: " . $title;
        $log_stmt->execute([1, 'Add Media Resource', 'MediaResource', $resourceID, $description, $ip_address]);

        // Commit the transaction
        $conn->commit();

        echo "<div class='alert alert-success' role='alert'>New media resource added successfully!</div>";
    } catch (PDOException $e) {
        // Rollback the transaction if an error occurs
        $conn->rollBack();
        echo "<div class='alert alert-danger' role='alert'>Error: " . $e->getMessage() . "</div>";
    }

    // Close the database connection
    $conn = null;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Media Resource</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5">
    <!-- Use a row to center the card and make it smaller -->
    <div class="row justify-content-center">
        <div class="col-12 col-md-6 col-lg-4">
            <div class="card shadow-sm">
                <div class="card-header text-center">
                    <h5>Add New Media Resource</h5>
                </div>
                <div class="card-body">
                    <!-- Form for adding a new media resource -->
                    <form action="add_media_resource.php" method="POST">
                        
                        <!-- Title -->
                        <div class="mb-3">
                            <label for="title" class="form-label">Title</label>
                            <input type="text" name="title" id="title" class="form-control form-control-sm" required>
                        </div>

                        <!-- Accession Number -->
                        <div class="mb-3">
                            <label for="accession_number" class="form-label">Accession Number</label>
                            <input type="text" name="accession_number" id="accession_number" class="form-control form-control-sm" required>
                        </div>

                        <!-- Acquisition Year -->
                        <div class="mb-3">
                            <label for="acquisition_year" class="form-label">Acquisition Year</label>
                            <input type="number" name="acquisition_year" id="acquisition_year" class="form-control form-control-sm" required>
                        </div>

                        <!-- Format -->
                        <div class="mb-3">
                            <label for="format" class="form-label">Format</label>
                            <input type="text" name="format" id="format" class="form-control form-control-sm" required>
                        </div>

                        <!-- Runtime -->
                        <div class="mb-3">
                            <label for="runtime" class="form-label">Runtime (in minutes)</label>
                            <input type="number" name="runtime" id="runtime" class="form-control form-control-sm" required>
                        </div>

                        <!-- Media Type -->
                        <div class="mb-3">
                            <label for="media_type" class="form-label">Media Type</label>
                            <input type="text" name="media_type" id="media_type" class="form-control form-control-sm" required>
                        </div>

                        <!-- Author -->
                        <div class="mb-3">
                            <label for="author" class="form-label">Author</label>
                            <input type="text" name="author" id="author" class="form-control form-control-sm" required>
                        </div>

                        <!-- Quantity -->
                        <div class="mb-3">
                            <label for="quantity" class="form-label">Quantity</label>
                            <input type="number" name="quantity" id="quantity" class="form-control form-control-sm" min="1" required>
                        </div>

                        <!-- Submit Button -->
                        <button type="submit" class="btn btn-primary w-100">Add Media Resource</button>
                    </form>
                </div>
                <div class="card-footer text-center">
                    <a href="../admin_dashboard.php" class="btn btn-secondary btn-sm">Back to Dashboard</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap 5 JS (Optional, for better interactivity) -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

</body>
</html>
