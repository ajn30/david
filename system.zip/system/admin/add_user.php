<?php
session_start();
require_once '../db.php'; // Include the database connection

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize input data
    $name = filter_var(trim($_POST['name']), FILTER_SANITIZE_SPECIAL_CHARS);
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    
    // Ensure the email is valid
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = 'Invalid email format.';
        header('Location: add_user.php');
        exit();
    }

    // Ensure user_type is valid
    $user_type = in_array($_POST['user_type'], ['student', 'faculty', 'staff', 'admin']) ? $_POST['user_type'] : 'student';
    
    // Hash the password
    $password = password_hash(trim($_POST['password']), PASSWORD_BCRYPT);

    // Sanitize membership_id
    $membership_id = filter_var(trim($_POST['membership_id']), FILTER_SANITIZE_SPECIAL_CHARS);

    try {
        // Check if the email already exists
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $existing_user = $stmt->fetch();

        if ($existing_user) {
            $_SESSION['error'] = 'Email already in use. Please use a different email address.';
        } else {
            // Insert user into the database
            $stmt = $pdo->prepare("INSERT INTO users (name, email, user_type, password, membership_id) 
                                   VALUES (:name, :email, :user_type, :password, :membership_id)");
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':user_type', $user_type);
            $stmt->bindParam(':password', $password);
            $stmt->bindParam(':membership_id', $membership_id);

            if ($stmt->execute()) {
                // Log the user creation action
                $user_id = $pdo->lastInsertId(); // Get the newly inserted user ID
                $log_query = "INSERT INTO activity_log (UserID, ActionType, ResourceType, ResourceID, Description, IP_Address) 
                              VALUES (?, ?, ?, ?, ?, ?)";
                $log_stmt = $pdo->prepare($log_query);
                $ip_address = $_SERVER['REMOTE_ADDR'];
                $description = "User added: " . $name;
                $log_stmt->execute([
                    $user_id,
                    'Add User', 
                    'User',
                    $user_id,
                    $description,
                    $ip_address
                ]);

                $_SESSION['success'] = 'User added successfully!';
                header('Location: manage_users.php');
                exit();
            } else {
                $_SESSION['error'] = 'Error adding user. Please try again.';
            }
        }
    } catch (PDOException $e) {
        // Log the error and display a generic message
        error_log("Error: " . $e->getMessage());
        $_SESSION['error'] = 'Something went wrong. Please try again later.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New User</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

    <!-- Display error or success message -->
    <?php if (isset($_SESSION['error'])): ?>
        <div style="color: red; padding: 10px; border: 1px solid red;">
            <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        </div>
    <?php elseif (isset($_SESSION['success'])): ?>
        <div style="color: green; padding: 10px; border: 1px solid green;">
            <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
        </div>
    <?php endif; ?>

    <!-- Button to trigger modal -->
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addUserModal">
        Add New User
    </button>

    <!-- Modal -->
    <div class="modal" id="addUserModal">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Add New User</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal Body -->
                <div class="modal-body">
                    <form method="POST" action="add_user.php">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" id="name" name="name" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="user_type">User Type</label>
                            <select id="user_type" name="user_type" class="form-control" required>
                                <option value="student">Student</option>
                                <option value="faculty">Faculty</option>
                                <option value="staff">Staff</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" id="password" name="password" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="membership_id">Membership ID</label>
                            <input type="text" id="membership_id" name="membership_id" class="form-control" required>
                        </div>

                        <button type="submit" class="btn btn-success">Add User</button>
                    </form>
                </div>

                <!-- Modal Footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>

    <!-- Include Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.11.6/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
