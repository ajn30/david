<?php
session_start();
require_once '../db.php'; // Include the database connection file

// Check if the user is an admin
if (!isset($_SESSION['user']) || $_SESSION['user']['user_type'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

// Fetch all books for viewing, extracting only the Year from PublicationDate
$query = "SELECT BookID, Title, Author, Genre, YEAR(PublicationDate) AS Year FROM books ORDER BY BookID DESC";
$books = $pdo->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Books</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

    <div class="container mt-4">
        <!-- Header Section -->
        <header>
            <h1 class="text-center mb-4">Manage Books</h1>
        </header>

        <!-- Main Content -->
        <main>
            <!-- Action Buttons -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <a href="book/add_book.php" class="btn btn-success w-100">Add New Book</a>
                </div>
                <div class="col-md-3">
                    <a href="total_resources/view_total_resources.php" class="btn btn-primary w-100">View Book List</a>
                </div>
                <div class="col-md-3">
                    <a href="media/add_media_resource.php" class="btn btn-warning w-100">Add New Media</a>
                </div>
                <div class="col-md-3">
                    <a href="periodicals/add_periodical.php" class="btn btn-info w-100">Add New Periodical</a>
                </div>
            </div>

            <!-- Book List Table -->
            <h2 class="mb-3">Book List</h2>
            <?php if ($books->rowCount() > 0): ?>
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Book ID</th>
                            <th>Title</th>
                            <th>Author</th>
                            <th>Genre</th>
                            <th>Year</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($book = $books->fetch(PDO::FETCH_ASSOC)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($book['BookID']); ?></td>
                                <td><?php echo htmlspecialchars($book['Title']); ?></td>
                                <td><?php echo htmlspecialchars($book['Author']); ?></td>
                                <td><?php echo htmlspecialchars($book['Genre']); ?></td>
                                <td><?php echo isset($book['Year']) ? htmlspecialchars($book['Year']) : 'N/A'; ?></td>
                                <td>
                                    <a href="book/edit_book.php?id=<?php echo $book['BookID']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <form action="delete_book.php" method="POST" style="display:inline;">
                                        <input type="hidden" name="book_id" value="<?php echo $book['BookID']; ?>">
                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirmDelete()">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="alert alert-warning">No books available to display.</div>
            <?php endif; ?>
        </main>
    </div>

    <!-- Bootstrap 5 JS and Dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Confirmation for Delete -->
    <script>
        function confirmDelete() {
            return confirm('Are you sure you want to delete this book? This action cannot be undone.');
        }
    </script>
</body>
</html>
