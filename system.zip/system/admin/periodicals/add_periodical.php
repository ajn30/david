<?php
// Include database connection file
require_once('../../db.php');  // Adjust the path as necessary

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the form data
    $title = $_POST['title'];
    $accessionNumber = $_POST['accession_number'];
    $acquisitionYear = $_POST['acquisition_year'];
    $issn = $_POST['issn'];
    $volume = $_POST['volume'];
    $issue = $_POST['issue'];
    $publicationDate = $_POST['publication_date'];
    $author = $_POST['author'];
    $quantity = $_POST['quantity'];
    $available_quantity = $quantity;  // Assuming available_quantity is the same as quantity when adding a new periodical

    // Create a new PDO instance
    try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Start a transaction
        $conn->beginTransaction();

        // Insert into libraryresources table (including available_quantity)
        $stmt = $conn->prepare("INSERT INTO libraryresources (Title, AccessionNumber, Category, AcquisitionYear, AvailabilityStatus, Available_quantity) 
                               VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$title, $accessionNumber, 'Periodical', $acquisitionYear, 'Available', $available_quantity]);
        $resourceID = $conn->lastInsertId();  // Get the last inserted ResourceID

        // Insert into periodicals table (including available_quantity)
        $stmt = $conn->prepare("INSERT INTO periodicals (ResourceID, Title, ISSN, Volume, Issue, PublicationDate, Author, Quantity, Available_Quantity) 
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$resourceID, $title, $issn, $volume, $issue, $publicationDate, $author, $quantity, $available_quantity]);

        // Log the addition of the new periodical
        $log_query = "INSERT INTO activity_log (UserID, ActionType, ResourceType, ResourceID, Description, IP_Address) 
                      VALUES (?, ?, ?, ?, ?, ?)";
        $log_stmt = $conn->prepare($log_query);
        $ip_address = $_SERVER['REMOTE_ADDR'];
        $description = "Periodical added: " . $title;
        $log_stmt->execute([1, 'Add Periodical', 'Periodical', $resourceID, $description, $ip_address]);

        // Commit the transaction
        $conn->commit();

        echo "<div class='alert alert-success'>New periodical added successfully!</div>";
    } catch (PDOException $e) {
        // Rollback the transaction if an error occurs
        $conn->rollBack();
        echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }

    // Close the database connection
    $conn = null;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Periodical</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5">
    <h2 class="mb-4">Add New Periodical</h2>

    <!-- Form for adding a new periodical -->
    <form action="add_periodical.php" method="POST">
        <div class="mb-3">
            <label for="title" class="form-label">Title</label>
            <input type="text" name="title" id="title" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="accession_number" class="form-label">Accession Number</label>
            <input type="text" name="accession_number" id="accession_number" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="acquisition_year" class="form-label">Acquisition Year</label>
            <input type="number" name="acquisition_year" id="acquisition_year" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="issn" class="form-label">ISSN</label>
            <input type="text" name="issn" id="issn" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="volume" class="form-label">Volume</label>
            <input type="text" name="volume" id="volume" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="issue" class="form-label">Issue</label>
            <input type="text" name="issue" id="issue" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="publication_date" class="form-label">Publication Date</label>
            <input type="date" name="publication_date" id="publication_date" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="author" class="form-label">Author</label>
            <input type="text" name="author" id="author" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="quantity" class="form-label">Quantity</label>
            <input type="number" name="quantity" id="quantity" class="form-control" min="1" required>
        </div>

        <button type="submit" class="btn btn-primary">Add Periodical</button>
    </form>

    <br>
    <a href="../admin_dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
</div>

<!-- Bootstrap 5 JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

</body>
</html>
