<?php
session_start(); // Start the session at the top of the file

// Session security: Regenerate session ID to prevent session fixation
session_regenerate_id(true);

// Make sure the user is an admin before proceeding
if (!isset($_SESSION['user']) || $_SESSION['user']['user_type'] !== 'admin') {
    // If not logged in or not an admin, redirect to login page
    header('Location: ../auth/login.php');
    exit();
}

// Database connection (assuming db.php contains a working PDO connection)
require_once '../db.php';

// Fetch statistics with error handling
try {
    // Updated query to count total resources in the 'libraryresources' table
    $resourceCount = $pdo->query("SELECT COUNT(*) FROM libraryresources")->fetchColumn();
    $userCount = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    // Updated query to use 'borrow_records' instead of 'borrowings'
    $borrowedBooksCount = $pdo->query("SELECT COUNT(*) FROM borrow_records WHERE return_date IS NULL")->fetchColumn();
} catch (PDOException $e) {
    echo "Error fetching statistics: " . $e->getMessage();
    exit();
}

// Get the logged-in admin's name
$adminName = htmlspecialchars($_SESSION['user']['name']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Custom styles for the background */
        body {
            background-color: #f4f4f9;
        }

        /* Modal styles */
        .modal-content {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .modal-header h2 {
            margin: 0;
        }

        .close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

    </style>
</head>
<body>
    <!-- Header Section -->
    <header class="bg-dark text-white py-3 text-center">
        <h1>Admin Dashboard</h1>
        <p>Welcome, <?php echo $adminName; ?></p>
    </header>

    <!-- Main Container -->
    <div class="container my-5">
        <div class="row mb-4">
            <!-- Total Resources Card -->
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h2><a href="total resources/view_total_resources.php" class="text-primary"><?php echo $resourceCount; ?></a></h2>
                        <p>Total Resources</p>
                    </div>
                </div>
            </div>
            <!-- Total Users Card -->
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h2><a href="manage_users.php" class="text-primary"><?php echo $userCount; ?></a></h2>
                        <p>Total Users</p>
                    </div>
                </div>
            </div>
            <!-- Currently Borrowed Books Card -->
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h2><?php echo $borrowedBooksCount; ?></h2>
                        <p>Currently Borrowed Books</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Navigation Links Section -->
        <div class="text-center">
            <a href="manage_users.php" class="btn btn-primary mx-2">Manage Users</a>
            <a href="manage_books.php" class="btn btn-primary mx-2">Manage Books</a>
            <a href="activity_logs.php" class="btn btn-primary mx-2">View Activity Logs</a>
            <a href="reports.php" class="btn btn-primary mx-2" id="reportsBtn">Reports</a>
            <a href="../auth/logout.php" class="btn btn-danger mx-2">Logout</a>
        </div>
    </div>

    <!-- Modal for Adding New User -->
    <div id="addUserModal" class="modal fade" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <h2 class="modal-title" id="addUserModalLabel">Add New User</h2>
                </div>
                <div class="modal-body">
                    <form action="add_user.php" method="POST" onsubmit="return validateForm()">
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" id="name" name="name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" id="email" name="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="user_type" class="form-label">User Type</label>
                            <select id="user_type" name="user_type" class="form-select" required>
                                <option value="student">Student</option>
                                <option value="faculty">Faculty</option>
                                <option value="staff">Staff</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" id="password" name="password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="membership_id" class="form-label">Membership ID</label>
                            <input type="text" id="membership_id" name="membership_id" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-success">Add User</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle (includes Popper for modals) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Form validation before submitting
        function validateForm() {
            let valid = true;
            document.querySelectorAll('.form-control').forEach(input => {
                if (input.value === '') {
                    valid = false;
                    input.classList.add('is-invalid');
                } else {
                    input.classList.remove('is-invalid');
                }
            });
            return valid;
        }
    </script>
</body>
</html>
        