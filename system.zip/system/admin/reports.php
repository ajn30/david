<?php
require_once '../db.php'; // Database connection file

// Create the connection using PDO
$conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);

// Check connection
if (!$conn) {
    die("Connection failed: " . $conn->errorInfo()[2]);
}

// 1. Overdue Books Report
try {
    $overdueBooksSql = "SELECT transactions.id AS transaction_id, users.name AS user_name, books.title AS book_title, transactions.due_date,
                        DATEDIFF(CURDATE(), transactions.due_date) AS overdue_days, transactions.fine_amount
                        FROM transactions
                        JOIN users ON transactions.user_id = users.id
                        JOIN books ON transactions.book_id = books.id
                        WHERE transactions.return_date IS NULL AND transactions.due_date < CURDATE()";
    $stmt = $conn->prepare($overdueBooksSql);
    $stmt->execute();
    $overdueBooksResult = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $overdueBooksResult = [];
}

// 2. Books Borrowed Report (Most Borrowed Books)
try {
    $mostBorrowedBooksSql = "SELECT books.title AS book_title, COUNT(*) AS borrow_count
                             FROM transactions
                             JOIN books ON transactions.book_id = books.id
                             GROUP BY books.title
                             ORDER BY borrow_count DESC";
    $stmt = $conn->prepare($mostBorrowedBooksSql);
    $stmt->execute();
    $mostBorrowedBooksResult = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $mostBorrowedBooksResult = [];
}

// 3. Fine Report (All fines and outstanding fines)
try {
    $fineReportSql = "SELECT users.name AS user_name, SUM(transactions.fine_amount) AS total_fines
                      FROM transactions
                      JOIN users ON transactions.user_id = users.id
                      WHERE transactions.return_date IS NOT NULL AND transactions.fine_amount > 0
                      GROUP BY users.name";
    $stmt = $conn->prepare($fineReportSql);
    $stmt->execute();
    $fineReportResult = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $fineReportResult = [];
}

// 4. Inventory Report by Resources
try {
    // Modified query for inventory report pulling from the `resources` table
    $inventoryReportSql = "SELECT categories.name AS category_name, COUNT(*) AS total_resources
                           FROM resources
                           JOIN categories ON resources.category_id = categories.id
                           GROUP BY categories.name";
    $stmt = $conn->prepare($inventoryReportSql);
    $stmt->execute();
    $inventoryReportResult = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $inventoryReportResult = [];
}

// Close the connection
$conn = null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Reports</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .report-section {
            display: none;
        }
    </style>
</head>
<body class="bg-light">

<div class="container py-5">
    <div id="header" class="mb-4">
        <a href="admin_dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
    </div>

    <h1 class="mb-4">Library Reports</h1>

    <!-- Buttons to toggle the reports -->
    <div class="mb-4">
        <button onclick="showReport('overdueBooks')" class="btn btn-primary">Overdue Books Report</button>
        <button onclick="showReport('mostBorrowedBooks')" class="btn btn-primary">Most Borrowed Books</button>
        <button onclick="showReport('fineReport')" class="btn btn-primary">Fine Report</button>
        <button onclick="showReport('inventoryReport')" class="btn btn-primary">Inventory Report</button>
        <button onclick="showAllReports()" class="btn btn-secondary">View All Reports</button>
    </div>

    <!-- Overdue Books Report -->
    <div id="overdueBooks" class="report-section">
        <h2>Overdue Books Report</h2>
        <?php if (count($overdueBooksResult) > 0): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Transaction ID</th>
                    <th>User Name</th>
                    <th>Book Title</th>
                    <th>Due Date</th>
                    <th>Overdue Days</th>
                    <th>Fine Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($overdueBooksResult as $overdueBook): ?>
                <tr>
                    <td><?php echo htmlspecialchars($overdueBook['transaction_id']); ?></td>
                    <td><?php echo htmlspecialchars($overdueBook['user_name']); ?></td>
                    <td><?php echo htmlspecialchars($overdueBook['book_title']); ?></td>
                    <td><?php echo htmlspecialchars($overdueBook['due_date']); ?></td>
                    <td><?php echo htmlspecialchars($overdueBook['overdue_days']); ?> days</td>
                    <td><?php echo htmlspecialchars($overdueBook['fine_amount']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p>No overdue books found.</p>
        <?php endif; ?>
    </div>

    <!-- Most Borrowed Books Report -->
    <div id="mostBorrowedBooks" class="report-section">
        <h2>Most Borrowed Books</h2>
        <?php if (count($mostBorrowedBooksResult) > 0): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Book Title</th>
                    <th>Borrow Count</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($mostBorrowedBooksResult as $mostBorrowedBook): ?>
                <tr>
                    <td><?php echo htmlspecialchars($mostBorrowedBook['book_title']); ?></td>
                    <td><?php echo htmlspecialchars($mostBorrowedBook['borrow_count']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p>No data available for most borrowed books.</p>
        <?php endif; ?>
    </div>

    <!-- Fine Report -->
    <div id="fineReport" class="report-section">
        <h2>Fine Report</h2>
        <?php if (count($fineReportResult) > 0): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>User Name</th>
                    <th>Total Fines</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($fineReportResult as $fineReport): ?>
                <tr>
                    <td><?php echo htmlspecialchars($fineReport['user_name']); ?></td>
                    <td><?php echo htmlspecialchars($fineReport['total_fines']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p>No fines data available.</p>
        <?php endif; ?>
    </div>

    <!-- Inventory Report by Category (Updated for resources) -->
    <div id="inventoryReport" class="report-section">
        <h2>Inventory Report</h2>
        <?php if (count($inventoryReportResult) > 0): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Category</th>
                    <th>Total Resources</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($inventoryReportResult as $inventoryReport): ?>
                <tr>
                    <td><?php echo htmlspecialchars($inventoryReport['category_name']); ?></td>
                    <td><?php echo htmlspecialchars($inventoryReport['total_resources']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p>No inventory data available.</p>
        <?php endif; ?>
    </div>
</div>

<!-- Bootstrap 5 JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

<script>
    // Function to show the selected report and hide the others
    function showReport(reportId) {
        // Hide all reports
        const reports = document.querySelectorAll('.report-section');
        reports.forEach(function(report) {
            report.style.display = 'none';
        });

        // Show the selected report
        const selectedReport = document.getElementById(reportId);
        if (selectedReport) {
            selectedReport.style.display = 'block';
        }
    }

    // Function to show all reports
    function showAllReports() {
        const reports = document.querySelectorAll('.report-section');
        reports.forEach(function(report) {
            report.style.display = 'block';
        });
    }
</script>

</body>
</html>
