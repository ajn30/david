<?php
session_start();
require_once '../db.php'; // Database connection

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    header('Location: ../auth/login.php');
    exit;
}

// Initialize filters
$action_filter = isset($_GET['action']) ? $_GET['action'] : '';
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';

// Base query to fetch activity logs
$query = "SELECT al.ActivityLogID, al.UserID, u.email AS UserEmail, al.ActionType, al.ResourceType, al.ResourceID, al.Description, al.ActionDate, al.IP_Address 
          FROM activity_log al
          LEFT JOIN users u ON al.UserID = u.id"; // Replace u.UserID with u.id


// Initialize conditions array to handle filters
$conditions = [];

// Apply action filter if specified
if (!empty($action_filter)) {
    $conditions[] = "al.ActionType LIKE :action";
}

// Apply date range filter if specified
if (!empty($start_date) && !empty($end_date)) {
    $conditions[] = "al.ActionDate BETWEEN :start_date AND :end_date";
} elseif (!empty($start_date)) {
    $conditions[] = "al.ActionDate >= :start_date";
} elseif (!empty($end_date)) {
    $conditions[] = "al.ActionDate <= :end_date";
}

// If any conditions are set, append them to the query
if (!empty($conditions)) {
    $query .= " WHERE " . implode(" AND ", $conditions);
}

// Order the logs by action date in descending order
$query .= " ORDER BY al.ActionDate DESC";

// Prepare the statement
$stmt = $pdo->prepare($query);

// Bind parameters if the filter is applied
if (!empty($action_filter)) {
    $stmt->bindValue(':action', '%' . $action_filter . '%');
}

if (!empty($start_date)) {
    $stmt->bindValue(':start_date', $start_date);
}

if (!empty($end_date)) {
    $stmt->bindValue(':end_date', $end_date);
}

// Execute the query
$stmt->execute();
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activity Logs</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        th {
            background-color: #f4f4f4;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .hidden-print {
            display: block;
        }
        @media print {
            .hidden-print {
                display: none;
            }
            table {
                width: 100%;
                margin: 0;
                padding: 0;
            }
        }
    </style>
    <script>
        function printPage() {
            const printContent = document.getElementById("logTable").outerHTML;
            const printWindow = window.open("", "_blank", "width=800,height=600");
            printWindow.document.write("<html><head><title>Activity Logs</title><style>table { width: 100%; border-collapse: collapse; margin: 20px 0; } th, td { padding: 10px; text-align: left; border: 1px solid #ddd; } th { background-color: #f4f4f4; } tr:hover { background-color: #f1f1f1; }</style></head><body>");
            printWindow.document.write(printContent);
            printWindow.document.write("</body></html>");
            printWindow.document.close();
            printWindow.print();
        }

        function downloadCSV() {
            const rows = <?php echo json_encode($logs); ?>;
            let csvContent = "ActivityLogID,UserID,UserEmail,ActionType,ResourceType,ResourceID,Description,ActionDate,IP_Address\n";
            rows.forEach(row => {
                csvContent += `${row.ActivityLogID},${row.UserID},${row.UserEmail || 'N/A'},${row.ActionType},${row.ResourceType},${row.ResourceID},${row.Description},${row.ActionDate},${row.IP_Address || 'N/A'}\n`;
            });
            
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'activity_logs.csv';
            link.click();
        }
    </script>
</head>
<body class="bg-light">

<div class="container py-5">
    <!-- Title and Back Button -->
    <h1 class="mb-4">Activity Logs</h1>
    <a href="admin_dashboard.php" class="btn btn-secondary mb-3">Back to Dashboard</a>

    <!-- Filter/Search form -->
    <form method="GET" action="activity_logs.php" class="mb-4">
        <div class="row g-3">
            <!-- Action Filter -->
            <div class="col-md-3">
                <label for="action" class="form-label">Filter by Action</label>
                <select name="action" id="action" class="form-select">
                    <option value="">All</option>
                    <option value="add book" <?php echo ($action_filter === 'add book') ? 'selected' : ''; ?>>Add Book</option>
                    <option value="add media" <?php echo ($action_filter === 'add media') ? 'selected' : ''; ?>>Add Media</option>
                    <option value="add periodical" <?php echo ($action_filter === 'add periodical') ? 'selected' : ''; ?>>Add Periodical</option>
                    <option value="delete resources" <?php echo ($action_filter === 'delete resources') ? 'selected' : ''; ?>>Delete Resources</option>
                    <option value="add user" <?php echo ($action_filter === 'add user') ? 'selected' : ''; ?>>Add User</option>
                    <option value="delete user" <?php echo ($action_filter === 'delete user') ? 'selected' : ''; ?>>Delete User</option>
                    <option value="borrow book" <?php echo ($action_filter === 'borrow book') ? 'selected' : ''; ?>>Borrow Book</option>
                    <option value="return book" <?php echo ($action_filter === 'return book') ? 'selected' : ''; ?>>Return Book</option>
                </select>
            </div>

            <!-- Date Filters -->
            <div class="col-md-3">
                <label for="start_date" class="form-label">Start Date</label>
                <input type="date" name="start_date" id="start_date" class="form-control" value="<?php echo htmlspecialchars($start_date); ?>">
            </div>
            <div class="col-md-3">
                <label for="end_date" class="form-label">End Date</label>
                <input type="date" name="end_date" id="end_date" class="form-control" value="<?php echo htmlspecialchars($end_date); ?>">
            </div>

            <div class="col-md-3">
                <button type="submit" class="btn btn-primary mt-4">Filter</button>
            </div>
        </div>
    </form>

    <!-- Print and CSV buttons -->
    <div class="hidden-print mb-3">
        <button onclick="printPage()" class="btn btn-info">Print View</button>
        <button onclick="downloadCSV()" class="btn btn-success">Download CSV</button>
    </div>

    <!-- Display Activity Logs Table -->
    <?php if (empty($logs)): ?>
        <p class="alert alert-warning">No activity logs available.</p>
    <?php else: ?>
        <table id="logTable" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>User ID</th>
                    <th>User Email</th>
                    <th>Action Type</th>
                    <th>Resource Type</th>
                    <th>Resource ID</th>
                    <th>Description</th>
                    <th>Action Date</th>
                    <th>IP Address</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($logs as $log): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($log['ActivityLogID']); ?></td>
                        <td><?php echo htmlspecialchars($log['UserID']); ?></td>
                        <td><?php echo htmlspecialchars($log['UserEmail'] ?: 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($log['ActionType']); ?></td>
                        <td><?php echo htmlspecialchars($log['ResourceType']); ?></td>
                        <td><?php echo htmlspecialchars($log['ResourceID']); ?></td>
                        <td><?php echo htmlspecialchars($log['Description']); ?></td>
                        <td><?php echo htmlspecialchars($log['ActionDate']); ?></td>
                        <td><?php echo htmlspecialchars($log['IP_Address'] ?: 'N/A'); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<!-- Bootstrap 5 JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

</body>
</html>
