<?php
require_once 'db.php';

$stmt = $pdo->prepare("
    UPDATE borrow_records
    SET fine_amount = fine_amount + 5
    WHERE return_date IS NULL AND TIMESTAMPDIFF(MINUTE, due_date, NOW()) >= 5
");
$stmt->execute();
