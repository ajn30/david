<?php
session_start();
require_once '../db.php'; // Adjust the path based on your directory structure

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and validate email
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = 'Invalid email format.';
        header('Location: login.php');
        exit();
    }

    // Sanitize and trim the password input
    $password = trim($_POST['password']);

    try {
        // Prepare the query to check if the user exists
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->execute();

        // Fetch the user from the database
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            $hashed_password = $user['password'];

            // Verify the password
            if (password_verify($password, $hashed_password)) {
                // The password is correct! Set session data and redirect based on user type
                $_SESSION['user'] = [
                    'id' => $user['id'],
                    'name' => $user['name'],
                    'email' => $user['email'],
                    'user_type' => $user['user_type']
                ];

                // Redirect based on user type
                switch ($user['user_type']) {
                    case 'admin':
                        header('Location: ../admin/admin_dashboard.php');
                        break;
                    case 'student':
                        header('Location: ../student/student_dashboard.php');
                        break;
                    case 'faculty':
                        header('Location: ../faculty/faculty_dashboard.php');
                        break;
                    case 'staff':
                        header('Location: ../staff/staff_dashboard.php');
                        break;
                    default:
                        $_SESSION['error'] = 'Invalid user type.';
                        header('Location: login.php');
                }
                exit();
            } else {
                // The password is incorrect!
                $_SESSION['error'] = 'Invalid email or password. Please try again.';
            }
        } else {
            // The email is incorrect!
            $_SESSION['error'] = 'Invalid email or password. Please try again.';
        }
    } catch (PDOException $e) {
        // Log the error and show a generic error message
        error_log("Database error: " . $e->getMessage());
        $_SESSION['error'] = 'Something went wrong. Please try again later.';
    }

    // Redirect back to the login page with error
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Include Font Awesome for Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        /* Apply the background image to the entire page */
        body {
            background-image: url('images/sds.jpg'); /* Replace with your image URL or local path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 100vh;      
            padding-top: 50px;
        }

        .container {
            max-width: 400px;
            background-color: rgba(255, 255, 255, 0.8); /* Semi-transparent white background */
            padding: 30px;
            border-radius: 10px;
        }

        .card-header {
            background-color: #007bff;
            color: white;
        }

        .alert {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="card">
            <div class="card-header text-center">
                <h4>Login</h4>
            </div>
            <div class="card-body">
                <!-- Display error message if there's any -->
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger">
                        <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="login.php">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <div class="input-group">
                            <!-- Font Awesome User Icon inside the Input Group -->
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                            <input type="email" id="email" name="email" class="form-control" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <div class="input-group">
                            <!-- Font Awesome Lock Icon inside the Input Group -->
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" id="password" name="password" class="form-control" required>
                            <!-- Toggle Password Visibility -->
                            <span class="input-group-text" style="cursor: pointer;" id="togglePassword" onclick="togglePasswordVisibility()">
                                <i class="fas fa-eye-slash" id="eyeIcon"></i>
                            </span>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">Login</button>
                </form>

                <div class="mt-3 text-center">
                    <a href="register.php">Create an account</a> | <a href="forgot_password.php">Forgot password?</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle Password Visibility
        function togglePasswordVisibility() {
            const passwordField = document.getElementById("password");
            const eyeIcon = document.getElementById("eyeIcon");

            if (passwordField.type === "password") {
                passwordField.type = "text";
                eyeIcon.classList.remove("fa-eye-slash");
                eyeIcon.classList.add("fa-eye");
            } else {
                passwordField.type = "password";
                eyeIcon.classList.remove("fa-eye");
                eyeIcon.classList.add("fa-eye-slash");
            }
        }
    </script>
</body>
</html>
