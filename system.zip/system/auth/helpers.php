<?php
// helpers.php

// Function to sanitize input data to prevent XSS attacks
function sanitize_input($data) {
    return htmlspecialchars(trim($data));
}

// Function to validate an email address
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Function to check if a user is logged in by checking the session
function check_logged_in() {
    return isset($_SESSION['user']);
}

// Function to redirect to a given page (useful for login or error handling)
function redirect($url) {
    header("Location: $url");
    exit();
}

// Function to hash a password before storing it in the database
function hash_password($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

// Function to verify a password against the stored hash
function verify_password($password, $hashed_password) {
    return password_verify($password, $hashed_password);
}

// Function to generate a random string for password reset or other purposes
function generate_random_string($length = 12) {
    return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $length);
}

// Function to check if the user has a specific role (e.g., admin)
function check_user_role($role) {
    return isset($_SESSION['user']) && $_SESSION['user']['role'] === $role;
}

// Function to format a timestamp to a more user-friendly format
function format_date($timestamp) {
    return date("F j, Y, g:i a", strtotime($timestamp));
}

// Function to generate a token for CSRF protection
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); // Generate a new token
    }
    return $_SESSION['csrf_token'];
}

// Function to validate the CSRF token (for security in form submissions)
function validate_csrf_token($token) {
    return isset($token) && $token === $_SESSION['csrf_token'];
}

// Function to count fines for overdue books (assuming you have a fine structure)
function calculate_fines($due_date) {
    $fine_rate = 0.50; // Fine rate per day (adjust based on your system)
    $current_date = new DateTime();
    $due_date = new DateTime($due_date);
    
    $interval = $current_date->diff($due_date);
    $days_overdue = $interval->days;

    if ($current_date > $due_date) {
        return $days_overdue * $fine_rate; // Calculate fines
    }

    return 0; // No fine if not overdue
}
?>
